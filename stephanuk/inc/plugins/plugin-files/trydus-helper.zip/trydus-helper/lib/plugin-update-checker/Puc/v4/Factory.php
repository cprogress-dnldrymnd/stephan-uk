<?php
if ( !class_exists('Puc_v4_Factory', false) ):

	class Puc_v4_Factory extends Puc_v4p10_Factory { }

endif;
