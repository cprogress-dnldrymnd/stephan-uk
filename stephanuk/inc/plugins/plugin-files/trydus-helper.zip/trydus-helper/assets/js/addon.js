(function ($) {

    "use strict";

    /* ---------------------------------------------

    Navigation menu

    --------------------------------------------- */

    // dropdown for mobile

    $(document).ready(function () {

  
    });

    $(window).load(function () {

    })

    
  var TrydusGlobal = function ($scope, $) {



    if ($scope.hasClass('trydus-sticky-yes')) {
      var current_widget = $scope;
      current_widget.wrap('<div class="sticky-wrapper"></div>');
      var headerHeight = $(current_widget).parent('.sticky-wrapper').height(),
        stickyWrapper = $(current_widget).parent('.sticky-wrapper');
      stickyWrapper.css('height', headerHeight + "px")
      window.onscroll = function () {
        scrollFunction()
      };

      function scrollFunction() {

        if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
          if ($scope.hasClass('trydus-sticky-yes')) {
            stickyWrapper.addClass("is-sticky");
            console.log(stickyWrapper);
          }
        } else {
          if ($scope.hasClass('trydus-sticky-yes')) {
            stickyWrapper.removeClass("is-sticky");
          }
        }
        if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
          if ($scope.hasClass('trydus-sticky-yes')) {
            $scope.addClass("reveal-sticky");
          }
        } else {
          if ($scope.hasClass('trydus-sticky-yes')) {
            $scope.removeClass("reveal-sticky");
          }
        } 

      }

    }
  }

    var TrydusductCategories = function () {
        if ($.fn.isotope) {
            var $gridMas = $('.product-categories-wrap.masonry');

            $gridMas.isotope({
                itemSelector: '.trydus-product-cat-wrap',
                percentPosition: true,
                layoutMode: 'packery',
            })

            $gridMas.imagesLoaded().progress(function () {
                $gridMas.isotope()
            });
        }
    }

    var ShadePostLoop = function () {
        if ($.fn.isotope) {

            $('.trydus-post-widget-area.masonry').isotope({
                itemSelector: '.trydus-post-widget-area.masonry>div',
                percentPosition: true,
                layoutMode: 'packery',
            })

        }
    }

    var ShadeJobLoop = function () {
        if ($.fn.owlCarousel) {
            $('.trydus-job-carousel').owlCarousel({
                margin: 30,
                responsiveClass: true,
                navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
                responsive: {
                    0: {
                        items: 1,
                        nav: true
                    },
                    768: {
                        items: 2,
                        nav: false
                    },
                    1000: {
                        items: 4,
                        nav: true,
                        loop: false
                    }
                }
            })
        }
    }

    //portfolio gallery js start
    var Trydus_Portfolio_Gallery_Js = function () {

        if ($.fn.isotope) {

            $(window).load(function () {
                var $gridMas = $('.trydus-pf-gallery-wrap.layout-mode-masonry');

                $gridMas.isotope({
                    itemSelector: '.trydus-pf-gallery-wrap .trydus-portfolio-item-wrap',
                    percentPosition: true,
                    layoutMode: 'packery',
                }).resize();

                $gridMas.imagesLoaded().progress(function () {
                    $gridMas.isotope()
                });
            })
        }

    }

    //portfolio js start
    var Trydus_Portfolio_Js = function () {
        if ($.fn.isotope) {

                var $gridMas = $('.trydus-portfolio-wrap.layout-mode-masonry');
                var $grid = $('.trydus-portfolio-wrap.layout-mode-normal');

                $grid.isotope({
                    itemSelector: '.trydus-portfolio-item-wrap',
                    percentPosition: true,
                    layoutMode: 'fitRows',
                }).resize()

                $grid.imagesLoaded().progress(function () {
                    $grid.isotope('layout')
                }).resize();

                $gridMas.isotope({
                    itemSelector: '.trydus-portfolio-item-wrap',
                    percentPosition: true,
                    layoutMode: 'packery',
                })

                $gridMas.imagesLoaded().progress(function () {
                    $gridMas.isotope('layout')
                });

                $grid.isotope().resize();
                $gridMas.isotope().resize();
                
                $(".pf-isotope-nav li").on('click', function () {
                    $(".pf-isotope-nav li").removeClass("active");
                    $(this).addClass("active");

                    var selector = $(this).attr("data-filter");
                    $gridMas.isotope({
                        filter: selector,
                        animationOptions: {
                            duration: 750,
                            easing: "linear",
                            queue: false,
                        }
                    });

                    var selector = $(this).attr("data-filter");
                    $grid.isotope({
                        filter: selector,
                        animationOptions: {
                            duration: 750,
                            easing: "linear",
                            queue: false,
                        }
                    });


                });

        }

        // comment load more button click event
        $('.trydus-pf-loadmore-btn').on('click', function () {
            var button = $(this);

            // decrease the current comment page value
            var dpaged = button.data('paged'),
                total_pages = button.data('total-page'),
                nonce = button.data('referrar'),
                ajaxurl = button.data('url');

            dpaged++;
            // console.log(foio_portfolio_js_datas);
            $.ajax({
                url: ajaxurl, // AJAX handler, declared before
                dataType: 'html',
                data: {
                    'action': 'trydus_loadmore_callback', // wp_ajax_cloadmore
                    // 'post_id': foio_portfolio_js_datas.parent_post_id, // the current post
                    'paged': dpaged, // current comment page
                    'folio_nonce': nonce,
                    'portfolio_settings': button.data('portfolio-settings'),
                },
                type: 'POST',
                beforeSend: function (xhr) {
                    button.text('Loading...'); // preloader here
                },
                success: function (data) {
                    if (data) {
                        $('.trydus-portfolio-wrap').append(data);
                        $('.trydus-portfolio-wrap').isotope('reloadItems').isotope()
                        button.text('More projects');
                        button.data('paged', dpaged);
                        // if the last page, remove the button
                        if (total_pages == dpaged)
                            button.remove();
                    } else {
                        button.remove();
                    }
                }
            });
            return false;
        });

    }


    var trydusTestimonail = function ($scope, $) {
        //adding popup video 
        if ($.fn.magnificPopup) {
            $('.trydus-popup-youtube').magnificPopup({
                type: 'iframe',
                mainClass: 'mfp-fade',
            });
        }


        var postwrapper = $scope.find(".trydus--testimonial");

        if (postwrapper.length === 0)
            return;

        var settings = postwrapper.data('settings');

        /*--------------------------------------------------------------
        trydus slider js
        --------------------------------------------------------------*/
        var postwrapper = $('.trydus--testimonial'),
            rtl = $('body').hasClass('rtl') ? true : false;

        postwrapper.owlCarousel({
            rtl: rtl,
            loop: settings['loop'],
            autoplay: settings['autoplay'],
            nav: settings['nav'],
            animateOut: 'fadeOut',
            animateIn: 'fadeIn',
            autoplaytimeout: settings['autoplaytimeout'],
            items: 1,
            navText: ['<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none" style="transform: rotate(180deg);"><path d="M1.16669 14H26.25" stroke="#fff" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M18.0834 5.83334L26.25 14L18.0834 22.1667" stroke="#fff" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
                '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none"><path d="M1.16669 14H26.25" stroke="#fff" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path><path d="M18.0834 5.83334L26.25 14L18.0834 22.1667" stroke="#fff" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
            ],
        });

    }

    var Trydus_Back_To_Top = function ($scope, $) {
        //adding popup video 

        $('.trydus-popup-youtube').magnificPopup({
            type: 'iframe',
            mainClass: 'mfp-fade',
        });



        /*--------------------------------------------------------------
        trydus slider js
        --------------------------------------------------------------*/
        var postwrapper = $('.trydus--testimonial');

        jQuery(".trydus-back-to-top-wraper").click(function () {
            jQuery("html, body").animate({
                scrollTop: 0
            }, 1000);
        });

        function stickyHeader($class) {
            jQuery(window).on('scroll', function () {
                var headerHeight = 600;
                if (jQuery(window).scrollTop() >= headerHeight) {
                    jQuery('.trydus-back-to-top-wraper .trydus-icon').addClass('sticky-active');
                } else {
                    jQuery('.trydus-back-to-top-wraper .trydus-icon').removeClass('sticky-active');
                }
            });
        }

        stickyHeader('.trydus-back-to-top-wraper');

    }

    var navMenu = function ($scope, $) {

        $('.trydus-mega-menu').closest('.elementor-container').addClass('megamenu-full-container');
        var count = 0;
        $(".main-navigation ul.navbar-nav>li.trydus-mega-menu>.sub-menu>li").each(function (index) {
            count++;
            if ($(this).is('li:last-child')) {
                $(this).parent().addClass('mg-column-' + count);
                count = 0;
            }
        });

        $(".menu-item-has-children > a").append('<span class="dropdownToggle"><i class="fas fa-angle-down"></i></span>');

        function navMenu() {

            if (jQuery('.trydus-main-menu-wrap').hasClass('menu-style-inline')) {
                if (jQuery(window).width() < 960) {
                    jQuery('.trydus-main-menu-wrap').addClass('menu-style-flyout');
                    jQuery('.trydus-main-menu-wrap').removeClass('menu-style-inline');
                } else {
                    jQuery('.trydus-main-menu-wrap').removeClass('menu-style-flyout');
                    jQuery('.trydus-main-menu-wrap').addClass('menu-style-inline');
                }

                $(window).resize(function () {
                    if (jQuery(window).width() < 960) {
                        jQuery('.trydus-main-menu-wrap').addClass('menu-style-flyout');
                        jQuery('.trydus-main-menu-wrap').removeClass('menu-style-inline');
                    } else {
                        jQuery('.trydus-main-menu-wrap').removeClass('menu-style-flyout');
                        jQuery('.trydus-main-menu-wrap').addClass('menu-style-inline');
                    }
                })
            }

                // main menu toggleer icon (Mobile site only)
                $('[data-toggle="navbarToggler"]').on("click", function (e) {
                    $('.navbar').toggleClass('active');
                    $('.navbar-toggler-icon').toggleClass('active');
                    $('body').toggleClass('offcanvas--open');
                    e.stopPropagation();
                    e.preventDefault();

                });
                $('.navbar-inner').on("click", function (e) {
                    e.stopPropagation();
                });

                // Remove class when click on body
                $('body').on("click", function () {
                    $('.navbar').removeClass('active');
                    $('.navbar-toggler-icon').removeClass('active');
                    $('body').removeClass('offcanvas--open');
                });
                $('.main-navigation ul.navbar-nav li.menu-item-has-children>a').on("click", function (e) {
                    e.preventDefault();
                    $(this).siblings('.sub-menu').toggle();
                    $(this).parent('li').toggleClass('dropdown-active');
                })


        }

            
        console.log('okay')
        navMenu();


        $(window).on('resize', function(){
            if ($(window).width() > 960) {
                            
                $(".trydus-mega-menu> ul.sub-menu > li > a").unbind('click');// Navbar moved up
            }
        })
        
        $(window).on('resize', function(){
            if ($(window).width() > 960) {
                            
                $(".trydus-mega-menu> ul.sub-menu > li > a").unbind('click');// Navbar moved up
            }
        })
    }


    $(window).on("elementor/frontend/init", function () {

        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-product-categories.default", TrydusductCategories);
        // elementorFrontend.hooks.addAction("frontend/element_ready/trydus-cowork-search.default", ShadeSearch);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-job-loop.default", ShadeJobLoop);
        elementorFrontend.hooks.addAction("frontend/element_ready/blog-loop.default", ShadePostLoop);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-testimonial.default", trydusTestimonail);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-back-to-top.default", Trydus_Back_To_Top);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-portfolio.default", Trydus_Portfolio_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-portfolio-gallery.default", Trydus_Portfolio_Gallery_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/trydus-main-menu.default", navMenu);
        elementorFrontend.hooks.addAction("frontend/element_ready/global", TrydusGlobal);

    });

})(jQuery);