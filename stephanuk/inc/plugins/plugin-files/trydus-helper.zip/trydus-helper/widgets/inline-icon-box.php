<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusInlineIconBox extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'trydus-inline-icon-box';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('Trydus Inline Icon box', 'trydus-hp');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-bullet-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['trydus-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label' => __('Icon type', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'text'  => __('Text', 'trydus-hp'),
					'icon' => __('Icon', 'trydus-hp'),
				],
			]
		);
		$this->add_control(
			'icon',
			[
				'label' => __('Icon 1', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => ['icon_type' => 'icon']
			]
		);
		$this->add_control(
			'icon_text',
			[
				'label' => __('Icon Text', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => ['icon_type' => 'text']
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __('Title', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __('Description', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'box_url',
			[
				'label' => __('URL', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::URL,
			]
		);


		$this->end_controls_section();


		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'icon_style',
			[
				'label' => __('Icon', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __('Normal', 'trydus-hp'),
			]
		);
		$this->add_control(
			'icon_background',
			[
				'label' => __('Icon Background', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'change_icon_color',
			[
				'label' => __('Change Icon Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'trydus-hp'),
				'label_off' => __('Hide', 'trydus-hp'),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'icon_type' 		=> 'icon'
				]
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => __('Icon Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .trydus-inline-icon-box-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .trydus-inline-icon-box-icon svg path' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'change_icon_color' => 'yes',
					'icon_type' 		=> 'icon'

				]
			]
		);
		$this->add_control(
			'icon_text_color',
			[
				'label' => __('Icon Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_type' 		=> 'text'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_shadow',
				'label' => __('Icon Shadow', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-wrap .trydus-inline-icon-box-icon',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 7,
							'vertical' => 6,
							'blur' => 20,
							'spread' => 0,
							'color' => 'rgba(0, 0, 0, 0.07)'
						]
					]
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __('Hover', 'trydus-hp'),
			]
		);

		$this->add_control(
			'icon_hover_background',
			[
				'label' => __('Icon Hover Background', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}:hover .trydus-inline-icon-box-icon' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => __('Icon Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}:hover .trydus-inline-icon-box-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}}:hover .trydus-inline-icon-box-icon svg' => 'color: {{VALUE}}',
					'{{WRAPPER}}:hover .trydus-inline-icon-box-icon svg path' => 'fill: {{VALUE}}',
				],
				'condition' => ['change_icon_color' => 'yes']
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_hover_shadow',
				'label' => __('Icon Shadow', 'trydus-hp'),
				'selector' => '{{WRAPPER}}:hover .trydus-inline-icon-box-wrap .trydus-inline-icon-box-icon',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 7,
							'vertical' => 6,
							'blur' => 20,
							'spread' => 0,
							'color' => 'rgba(0, 0, 0, 0.07)'
						]
					]
				]
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'icon_text_typo',
				'label' => __('Icon Text Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-icon',
				'condition' => ['icon_type' => 'text']
			]
		);
		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __('Icon Size', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-icon svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .trydus-inline-icon-box-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],

				'condition' => ['icon_type' => 'icon']
			]
		);
		$this->add_responsive_control(
			'icon_box_size',
			[
				'label' => __('Icon Box Size', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 57,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 57,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 57,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .trydus-inline-icon-box-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' => __('Icon Box Border Radius', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10'
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'space_between_icon',
			[
				'label' => __('Icon Gap', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-wrap' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'label' => __( 'Icon Border', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-icon',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'content_style',
			[
				'label' => __('Content', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'title_gap',
			[
				'label' => __('Title Gap', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __('Title Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#161C2D',
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_br',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => __('Description Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-content p',
			]
		);


		$this->add_control(
			'description_color',
			[
				'label' => __('Description Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#7A7A7A',
				'selectors' => [
					'{{WRAPPER}} .trydus-inline-icon-box-content p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$popular_post_key = array();
		$popular_meta_value_num = array();
		$settings = $this->get_settings_for_display();
		$target = $settings['box_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['box_url']['nofollow'] ? ' rel="nofollow"' : '';
?>

		<div class="trydus-inline-icon-item ">
			<?php if ($settings['box_url']['url']) { ?>
				<a <?php printf('href="%s" %s %s', $settings['box_url']['url'], $target, $nofollow) ?>>
				<?php }  ?>
				<div class="trydus-inline-icon-box-wrap">
					<span class="trydus-inline-icon-box-icon">
						<?php
						if ('text' == $settings['icon_type']) {
							echo esc_html($settings['icon_text']);
						} else {
							\Elementor\Icons_Manager::render_icon($settings["icon"], ['aria-hidden' => 'true']);
						}
						?>
					</span>
				</div>
				<div class="trydus-inline-icon-box-content">
					<h4 class="trydus-inline-icon-box-title"><?php echo $settings['title'] ?></h4>
					<p><?php echo $settings['description'] ?></p>
				</div>
				<?php if ($settings['box_url']['url']) { ?>
				</a>
			<?php } ?>
		</div>

<?php
	}
}
