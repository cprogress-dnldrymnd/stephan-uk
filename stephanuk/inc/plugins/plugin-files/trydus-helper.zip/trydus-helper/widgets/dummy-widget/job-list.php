<?php


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusJobList extends \Elementor\Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-job-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Job List', 'trydus-hp' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-site-title';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	 public function get_categories() {
 	    return [ 'trydus-addons' ];
 	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'trydus-hp' ),
			]
		);

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Posts per page', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
            ]
        );
        $this->add_control(
            'show_btn',
            [
                'label' => __( 'Show Readmore Button', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'trydus-hp' ),
				'label_off' => __( 'Show', 'trydus-hp' ),
				'return_value' => 'true',
				'default' => 'true',
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => __( 'Readmore Button Text', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View All Opening', 'trydus-hp' ),
				'condition' => [
					'show_btn' => 'true'
				]
            ]
		);
		$this->add_control(
			'button_align',
			[
				'label' => __( 'Button Align', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'trydus-hp' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'top', 'trydus-hp' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'trydus-hp' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'condition' => [
					'show_btn' => 'true'
				]
			]
		);
		$this->end_controls_section();


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Content', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn--color-dark' => 'color: {{VALUE}};',
					'{{WRAPPER}} .btn.btn--color-dark' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .btn-border-hover:before' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .btn.btn--color-dark',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings();
			
            $the_query = new WP_Query( array('posts_per_page'=>$settings['posts_per_page'],
                 'post_type'=>'career',
                 'paged' => get_query_var('paged') ? get_query_var('paged') : 1)
            );
            ?>
            <div class="row">
            <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
				<div class="col-12">

						<a href="<?php echo get_the_permalink() ?>" class="job-details-link d-block trydus-job-list-item">
							<?php the_title( '<h4>', '</h4>' ) ?>
							<div class="trydus-career-meta">
							<?php if(!empty(get_field('job_address'))): ?>
								<span class="job-address"> <img src="<?php echo get_template_directory_uri() . '/assets/img/map-pin-line.svg' ?>" alt="<?php echo esc_attr__( 'address', 'trydus' ) ?>">  <?php the_field('job_address') ?></span>
							<?php endif; ?>
							<?php if( !empty(get_field('job_type'))): ?>
								<span class="job-type"> <img src="<?php echo get_template_directory_uri() . '/assets/img/time-line.svg' ?>" alt="<?php echo esc_attr__( 'job type', 'trydus' ) ?>">  <?php the_field('job_type') ?></span>
							<?php endif; ?>
							</div>
							<i class="fa fa-arrow-right"></i>
						</a>

				</div>
            <?php
            endwhile;
			echo '</div>';
			if('true' == $settings['show_btn']):
			?>
			<div class="trydus-job-list-btn-wrap text-<?php echo $settings['button_align'] ?>">
				<a href="<?php echo get_post_type_archive_link('career') ?>" class="trydus-btn btn-type-boxed"><?php echo $settings['btn_text'] ?>
				</a>
			</div>
			<?php
			endif;
            wp_reset_postdata();

	}

}
