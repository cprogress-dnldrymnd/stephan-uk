<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusCountDown extends \Elementor\Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-countdown';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Countdown', 'trydus-hp' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	 public function get_categories() {
 	    return [ 'trydus-addons' ];
 	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'trydus-hp' ),
			]
		);

		$this->add_control(
			'date',
			[
				'label' => __( 'Date', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Time', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'time_color',
			[
				'label' => __( 'Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown .countdown__count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'time_typography',
				'selector' => '{{WRAPPER}} .countdown .countdown__count',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'text_style',
			[
				'label' => __( 'Time', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .countdown .text',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings();
        ?>
		<ul class="trydus-countdown d-flex mb-40 justify-content-center justify-content-lg-start" id="date" data-date="<?php echo $settings['date']; ?>">

			<li class="d-flex flex-column mr-60 text-left">
				<span class="text">Days</span>
				<span class="trydus-countdown__count h3-font font-w-700 color-primary" id="days"></span>
			</li>

			<li class="d-flex flex-column mr-60 text-left">
				<span class="text">Hours</span>
				<span class="trydus-countdown__count h3-font font-w-700 color-primary" id="hours"></span>

			</li>

			<li class="d-flex flex-column mr-60 text-left">
				<span class="text">Minutes</span>
				<span class="trydus-countdown__count h3-font font-w-700 color-primary" id="minutes"></span>
			</li>

			<li class="d-flex flex-column text-left">
				<span class="text">Seconds</span>
				<span class="trydus-countdown__count h3-font font-w-700 color-primary" id="seconds"></span>
			</li>
		</ul>
		<!-- end of countdown -->
        <?php
	}

}
