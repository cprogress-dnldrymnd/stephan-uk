<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusDoctorBox extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-doctor-box';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Doctor Box', 'trydus-hp' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-user-circle-o';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'trydus-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */

        $this->start_controls_section(
			'doctor_box',
			[
				'label' => __( 'Doctor Box', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'doctor_image',
			[
				'label' => __( 'Doctor Image', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'doctor_name',
			[
				'label' => __( 'Doctor Name', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
				'default' => 'Dr. David Herison',
			]
		);

		$this->add_control(
			'doctor_description', [
				'label' => __( 'Doctor Description', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
				'default' => __( 'Specialist, MD in Immune System Disorders (ISD)' , 'trydus-hp' ),
			]
		);



        $repeater = new \Elementor\Repeater();


		$repeater->add_control(
			'ability', [
                'label' => __( 'Specialized in', 'trydus-hp' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Asthma, eczema, food allergies', 'trydus-hp')
			]
		);



		$this->add_control(
			'ability_list',
			[
				'label' => __( 'Ability List', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
					[
						'ability' => __( 'Asthma, eczema, food allergies', 'trydus-hp' ),
					],
					[
						'ability' => __( 'Heart attack, high blood pressure', 'trydus-hp' ),
					],
					[
						'ability' => __( 'Colon cancer, hemorrhoids ', 'trydus-hp' ),
					],

				],
				'title_field' => '{{{ ability }}}',
			]
        );

        $repeater = new \Elementor\Repeater();


		$repeater->add_control(
			'button_label',
			[
				'label' => __( 'Button text', 'trydus-hp' ),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Call Now',
			]
		);
		$repeater->add_control(
			'button_url',
			[
				'label' => __( 'Button URL', 'trydus-hp' ),
				'type' =>  \Elementor\Controls_Manager::URL,
			]
        );
		$repeater->add_control(
			'button_focused',
			[
				'label' => __( 'Make it focsed', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( '', 'trydus-hp' ),
				'label_off' => __( 'focused', 'trydus-hp' ),
				'return_value' => 'focused',
			]
		);


		$this->add_control(
			'button_list',
			[
				'label' => __( 'Add Button', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
					[
                        'button_label' => __( 'Call Now', 'trydus-hp' ),
                        'button_focused' => 'focused',
					],
					[
						'button_label' => __( 'Availability', 'trydus-hp' ),
					],

                ],
				'title_field' => '{{{ button_label }}}',
			]
		);



		$this->end_controls_section();

		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_gap',
			[
				'label' => __( 'Image Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'name_gap',
			[
				'label' => __( 'Name Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 13,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 13,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-meta h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'desc_gap',
			[
				'label' => __( 'Description Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 15,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'aility_gap',
			[
				'label' => __( 'Ability Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-ability' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'name_typo',
				'label' => __( 'Name typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}}  .trydus-doctor-meta h3',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo',
				'label' => __( 'Description typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-doctor-meta p',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'ability_typo',
				'label' => __( 'Doctor Ability typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-doctor-ability li',
			]
		);


		$this->add_control(
			'name_color',
			[
				'label' => __( 'Name Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#0d152e',
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-meta h3' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Description Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#81838c',
				'selectors' => [
					'{{WRAPPER}} .trydus-doctor-meta p' => 'color: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'ability_color',
			[
				'label' => __( 'Ability Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#0d152e',
				'selectors' => [
					'{{WRAPPER}} trydus-doctor-ability li' => 'color: {{VALUE}}',
				]
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __( 'Box Shadow', 'trydus-hp' ),
                'selector' => '{{WRAPPER}} .trydus-doctor-box-item',
                'fields_options' =>
                    [
                        'box_shadow_type' =>
                        [
                            'default' =>'yes'
                        ],
                        'box_shadow' => [
                            'default' =>
                                [
                                    'horizontal' => 0,
                                    'vertical' => 3,
                                    'blur' => 7,
                                    'spread' => 0,
                                    'color' => 'rgba(0, 0, 0, 0.05)'
                                ]
                        ]
                    ]
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'hover_box_shadow',
                'label' => __( 'Hover Box Shadow', 'trydus-hp' ),
                'selector' => '{{WRAPPER}} .trydus-doctor-box-item:hover',
                'fields_options' =>
                    [
                        'box_shadow_type' =>
                        [
                            'default' =>'yes'
                        ],
                        'box_shadow' => [
                            'default' =>
                                [
                                    'horizontal' => 0,
                                    'vertical' => 33,
                                    'blur' => 77,
                                    'spread' => 0,
                                    'color' => ' rgba(0, 0, 0, 0.13)'
                                ]
                        ]
                    ]
            ]
        );

        $this->start_controls_tabs(
			'active_tabs'
		);

			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => __( 'Normal', 'trydus-hp' ),
				]
			);
			$this->add_control(
				'btn_color',
				[
					'label' => __( 'BUtton Color', 'trydus-hp' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#0d152e',
					'selectors' => [
						'{{WRAPPER}} a.trydus-doctor-btn' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'btn_background',
				[
					'label' => __( 'BUtton Background', 'trydus-hp' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} a.trydus-doctor-btn' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => __( 'Active', 'trydus-hp' ),
				]
			);

            $this->add_control(
				'accive_btn_color',
				[
					'label' => __( 'BUtton Color', 'trydus-hp' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} a.trydus-doctor-btn.focused' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'active_btn_background',
				[
					'label' => __( 'BUtton Background', 'trydus-hp' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#2bd67b',
					'selectors' => [
						'{{WRAPPER}} a.trydus-doctor-btn.focused' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();



	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
			<div class="trydus-doctor-box-item">
                <div class="trydus-doctor-image">
                    <img src="<?php echo $settings['doctor_image']['url'] ?>" alt="<?php echo $settings['doctor_name'] ?>">
                </div>
                <div class="trydus-doctor-meta">
                    <h3><?php echo $settings['doctor_name'] ?></h3>
                    <p><?php echo $settings['doctor_description'] ?></p>
                </div>
                <?php if($settings['ability_list']): ?>
                <ul class="trydus-doctor-ability">
                    <?php foreach($settings['ability_list'] as  $ability): ?>
                        <li><?php echo $ability['ability'] ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <?php if($settings['button_list']): ?>
                <div class="trydus-doctor-btn-wrap">
                    <?php foreach($settings['button_list'] as  $button):
                        $target = $button['button_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $button['button_url']['nofollow'] ? ' rel="nofollow"' : '';
                        $button_focused = $button['button_focused'] ? 'focused' : ''
                    ?>
                       <a class="trydus-doctor-btn <?php echo $button_focused ?>" href="<?php echo $button['button_url']['url'] ?>" <?php echo "{$target} {$nofollow}" ?>><?php echo $button['button_label'] ?></a>
                    <?php endforeach; ?>

                </div>
                <?php endif; ?>
            </div>
		<?php
	}

}

