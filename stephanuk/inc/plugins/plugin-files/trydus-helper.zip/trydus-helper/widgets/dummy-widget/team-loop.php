<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusTeamLoop extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'team-loop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Team Loop', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts per page', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
            ]
        );

        $this->add_control(
            'post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'col-md-12' => '1 Column',
                    'col-md-6' => '2 Column',
                    'col-md-4' => '3 Column',
                    'col-xl-3 col-md-4' => '4 Column',
                ),
                'default' => 'col-xl-3 col-md-4',
            ]
        );
        $this->add_control(
			'show_apply',
			[
				'label' => __('Show apply link?', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('No', 'trydus-hp'),
				'label_off' => __('yes', 'trydus-hp'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
            'apply_title',
            [
                'label' => __('Apply Title', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Interested to join 
                our team ?',
                'condition'	=> [
					'show_apply' => 'yes',
				]
            ]
        );
        $this->add_control(
            'apply_btn_title',
            [
                'label' => __('Apply Button Text', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Apply now',
                'condition'	=> [
					'show_apply' => 'yes',
				]
            ]
        );
        $this->add_control(
            'apply_url',
            [
                'label' => __('Apply Button Url', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::URL,
                'condition'	=> [
					'show_apply' => 'yes',
				]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'image_style',
            [
                'label' => __('Image', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'image_height',
            [
                'label' => __( 'Image Height', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-image img' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
            ]
        );
        $this->add_responsive_control(
            'image_spacing',
            [
                'label' => __( 'Image spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'member_name',
				'label' => __('Name typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .member-name',
			]
        );
        $this->add_control(
			'name_color',
			[
				'label' => __('Name Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .member-name' => 'color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __( 'Name Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->add_control(
			'position_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'member_postion',
				'label' => __('Postion typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .member-name',
			]
        );
        $this->add_control(
			'postion_color',
			[
				'label' => __('Postion Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .member-position' => 'color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
            'postion_spacing',
            [
                'label' => __( 'Postion Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .trydus-team-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'apply_style',
            [
                'label' => __('Apply Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition'	=> [
					'show_apply' => 'yes',
				]
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'apply_title',
				'label' => __('Apply Title typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .team-apply-card h4',
			]
        );
        $this->add_control(
			'apply_title_color',
			[
				'label' => __('Apply Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-apply-card h4' => 'color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
            'apply_title_spacing',
            [
                'label' => __( 'Apply Title Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .team-apply-card h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->add_control(
			'apply_link_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'apply_link_typo',
				'label' => __('Link %ext Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .team-apply-card  a',
			]
        );
        $this->add_control(
			'link_color',
			[
				'label' => __('Link Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-apply-card  a' => 'color: {{VALUE}}',
				]
			]
        );

        $this->add_responsive_control(
            'apply_padding',
            [
                'label' => __('Apply Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .team-apply-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
     
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();
        $target = $settings['apply_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['apply_url']['nofollow'] ? ' rel="nofollow"' : '';
        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'team',
            'order' => 'ASC',
        ));
?>
        <div class="container-fluid">
            <div class="row trydus-teams-wrap">
                <?php while ($the_query->have_posts()) : $the_query->the_post();
                    $idd = get_the_ID();
                ?>
                    <div class="<?php echo esc_attr($settings['post_grid']) ?>">
                        <a href="<?php echo esc_url(get_the_permalink()) ?>" class="trydus-team-item">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="member-image">
                                    <?php echo get_the_post_thumbnail($idd, 'large') ?>
                                </div>
                            <?php endif; ?>
                            <div class="member-details">
                                <h4 class="member-name"><?php echo get_the_title() ?></h4>
                                <span class="team-position"><?php echo get_field('position'); ?></span>
                            </div>
                        </a>
                    </div>
                <?php
                endwhile;
                wp_reset_postdata(); ?>
                <?php if('yes' == $settings['show_apply']): ?>
                <div class="<?php echo esc_attr( $settings['post_grid'] ) ?>">
                    <div class="team-apply-card">
                        <h4><?php echo esc_html($settings['apply_title']) ?></h4>
                        <a <?php  printf('href="%s" %s %s',$settings['apply_url']['url'] , $nofollow, $target ) ?>>
                            <?php echo esc_html($settings['apply_btn_title']) ?>
                            <i aria-hidden="true" class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

<?php
    }
}
