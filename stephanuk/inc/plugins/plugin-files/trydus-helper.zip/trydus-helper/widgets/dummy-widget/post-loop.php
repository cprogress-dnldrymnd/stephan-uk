<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusBlogLoop extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'blog-loop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Blog Loop', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts per page', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
            ]
        );

        $this->add_control(
            'enable_masonry',
            [
                'label' => __('Enable Masonry?', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'masonry',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'col-md-12' => '1 Column',
                    'col-lg-6' => '2 Column',
                    'col-lg-4 col-md-6' => '3 Column',
                    'col-lg-3 col-md-6' => '4 Column',
                ),
                'default' => 'col-lg-4 col-md-6',
            ]
        );

        $this->add_responsive_control(
            'bottom_spacing',
            [
                'label' => __('Bottom Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Show Excerpt', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_readmore',
            [
                'label' => __('Show Readmore', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'readmore_text',
            [
                'label' => __('Readmore Text', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Continue Reading',
                'condition' => [
                    'show_readmore' => 'yes'
                ],
            ]
        );



        $this->add_control(
            'show_pagination',
            [
                'label' => __('Show Pagination?', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );



        $this->end_controls_section();

        $this->start_controls_section(
            'content_style',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'post_cat',
            [
                'label' => __('Category Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .post-cat' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'cat_typo',
                'label' => __('Category Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-post-item .post-cat',
            ]
        );
        $this->add_control(
            'cat_color',
            [
                'label' => __('Category Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .post-cat' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'job_type_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control(
            'title_gap',
            [
                'label' => __('Title Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Title Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-post-item .entry-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .entry-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typ',
                'label' => __('Excerpt Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-post-item p',
            ]
        );


        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Excerpt Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_box_style',
            [
                'label' => __('Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-post-item:hover',
            ]
        );

        $this->add_responsive_control(
            'box_border_radius',
            [
                'label' => __('Box Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .entry-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'Content box_padding',
            [
                'label' => __('Content Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-item .post-content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'box_height',
            [
                'label' => __('Box height', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-post-wrap' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();

        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'post',
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        ));
?>
        <?php if ($the_query->have_posts()) : ?>
            <div class="row trydus-post-widget-area justify-content-center posts-row <?php echo $settings['enable_masonry'] ?>">
                <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                    <?php
                    $idd = get_the_ID();
                    if (has_category()) {
                        $post_cat = get_the_terms($idd, 'category');
                        $post_cat = join(', ', wp_list_pluck($post_cat, 'name'));
                    } else {
                        $post_cat = '';
                    }
                    $grid = '';
                    switch ($settings['post_grid']) {
                        case 'col-lg-6':
                            $limit = 17;
                            $title = wp_trim_words(get_the_title(), 11, '...');
                            $grid = 'two-column';
                            break;
                        case 'col-lg-4 col-md-6':
                            $limit = 17;
                            $title = wp_trim_words(get_the_title(), 11, '...');
                            $grid = 'three-column';
                            break;
                        case 'col-lg-3 col-md-6':
                            $limit = 14;
                            $title = wp_trim_words(get_the_title(), 11, '...');
                            $grid = 'three-column';
                            break;
                        default:
                            $limit = 30;
                            $title = get_the_title();
                            $grid = 'one-column';
                            break;
                    }

                    ?>
                    <div class="<?php echo $settings['post_grid'] ?>">
                        <div id="post-<?php the_ID(); ?>" <?php post_class('trydus-widget-post-wrap'); ?>>
                            <div href="<?php the_permalink(); ?>" class="trydus-widget-post-item single-post-item <?php echo esc_attr($grid) ?>">
                                <?php
                                if (has_post_thumbnail()) : ?>
                                    <div class="post-thumbnail-wrapper">
                                        <a href="<?php echo get_the_permalink(); ?>" class="post-thumbnail" aria-hidden="true" tabindex="-1">
                                            <?php
                                            the_post_thumbnail(
                                                'post-thumbnail',
                                                array(
                                                    'alt' => the_title_attribute(
                                                        array(
                                                            'echo' => false,
                                                        )
                                                    ),
                                                )
                                            );
                                            ?>
                                        </a>
                                    </div>
                                <?php
                                endif;
                                ?>
                                <div class="post-content-wrap">
                                    <span class="post-cat"><?php echo get_the_date(); ?></span>
                                    <?php
                                    echo '<h2 class="entry-title"><a href="' . get_the_permalink() . '">';
                                    echo $title;
                                    echo '</a></h2>';
                                    ?>
                                    <?php if ('yes' == $settings['show_excerpt']) {
                                        echo '<p>' . esc_html(wp_trim_words(get_the_excerpt(), $limit)) . '</p>';
                                    }
                                    ?>
                                    <?php if ('yes' == $settings['show_readmore']) : ?>
                                        <div class="post-read-more">
                                            <a href="<?php echo  esc_url(get_permalink()); ?>"><?php echo $settings['readmore_text'] ?></a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div><!-- #post-<?php the_ID(); ?> -->
                    </div>


                <?php
                endwhile;

                if ('yes' == $settings['show_pagination']) {

                    $total_pages = $the_query->max_num_pages;
                    $big = 999999999;
                    echo '<div class="col-12"><div class="trydus-navigation">';
                    if ($total_pages > 1) {
                        $current_page = max(1, get_query_var('paged'));
                        echo paginate_links(array(
                            'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                            'format'    => '?paged=%#%',
                            'current'   => $current_page,
                            'total'     => $total_pages,
                            'prev_text' => '<i class="fa fa-angle-left ml-10"></i>',
                            'next_text' => '<i class="fa fa-angle-right ml-10"></i>'
                        ));
                    }
                    echo '</div></div>';
                }


                wp_reset_postdata(); ?>
            </div>
<?php
        endif;
    }
}
