<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusPricingBox extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'trydus-pricing-box';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('Trydus Price Box', 'trydus-hp');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-price-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['trydus-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */

		$this->start_controls_section(
			'price_tables',
			[
				'label' => __('Price Box', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __('Price title', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Personal',
			]
		);

		$this->add_control(
			'focused',
			[
				'label' => __('Make it focsed', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('', 'trydus-hp'),
				'label_off' => __('focused', 'trydus-hp'),
				'return_value' => 'focused',
			]
		);



		$this->add_control(
			'price_currency',
			[
				'label' => __('Price Currency', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('', 'trydus-hp'),
			]
		);
		$this->add_control(
			'price',
			[
				'label' => __('Price Text', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('$29/mo', 'trydus-hp'),
			]
		);

		$this->add_control(
			'price_duration',
			[
				'label' => __('Price Duration', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('/ mo', 'trydus-hp'),
			]
		);

		$this->add_control(
			'price_description',
			[
				'label' => __('Price Description', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('$290 billed annualy', 'trydus-hp'),
			]
		);




		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'feature_icon',
			[
				'label' => __('Feature Icon', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-check-circle',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
			'feature_text',
			[
				'label' => __('Features', 'trydus-hp'),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
		);



		$this->add_control(
			'feature_list',
			[
				'label' => __('Feature List', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);


		$this->add_control(
			'button_label',
			[
				'label' => __('Button text', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Learn More',
			]
		);
		$this->add_control(
			'button_bottom_label',
			[
				'label' => __('Button Bottom text', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => '',
			]
		);
		$this->add_control(
			'btn_icon',
			[
				'label' => __('Button Icon', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-arrow-left',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'button_url',
			[
				'label' => __('Button URL', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::URL,
			]
		);

		$this->add_responsive_control(
			'content_align',
			[
				'label' => __('Align', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'trydus-hp'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('top', 'trydus-hp'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'trydus-hp'),
						'icon' => 'fa fa-align-right',
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'prefix_class' => 'content-align%s-',
				'toggle' => true,
			]
		);

		$this->end_controls_section();

		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'general',
			[
				'label' => __('Title', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => __('Title typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#473bf0',
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-title' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'title_bg_color',
			[
				'label' => __('Title Background Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-title' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __('Title Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'price_style',
			[
				'label' => __('Price', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'currency_typo',
				'label' => __('Price Currency Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-price .price-currency',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_typo',
				'label' => __('Price typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-price',
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => __('Price Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#0d152e',
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item .trydus-price' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'price_spacing',
			[
				'label' => __('Price Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item .trydus-price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_control(
			'price_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_dur_typo',
				'label' => __('Price Duration typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}}  .trydus-pricing-duration',
			]
		);
		$this->add_control(
			'duration_color',
			[
				'label' => __('Duration Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#6E727D',
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-duration' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'price_dur_spacing',
			[
				'label' => __('Duration Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_control(
			'price_dur_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_desc_typo',
				'label' => __('Price Description typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}}  .trydus-pricing-description',
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' => __('description Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#6E727D',
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-description' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'price_desc_spacing',
			[
				'label' => __('Price Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-price-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'feature_style',
			[
				'label' => __('Feature', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'features_typo',
				'label' => __('Features typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-features li',
			]
		);
		$this->add_control(
			'features_color',
			[
				'label' => __('Features Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#161c2d',
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-features li' => 'color: {{VALUE}}',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'feature_border',
				'label' => __('Border', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-features li',
			]
		);
		$this->add_control(
			'feature_border_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'feature_item_padding',
			[
				'label' => __('Feature Item Padding', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-features li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_padding',
			[
				'label' => __('Features Padding', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-features' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'feature_spacing',
			[
				'label' => __('Features Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-features' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'btn_style',
			[
				'label' => __('Button', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => __('Button typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-btn',
			]
		);
		$this->add_control(
			'button_color',
			[
				'label' => __('Button Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item .trydus-btn' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'button_hover_color',
			[
				'label' => __('Button Hover Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item .trydus-btn:hover' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'button_bg_color',
			[
				'label' => __('Button Background', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-btn' => 'background-color: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'button_bg_hover',
			[
				'label' => __('Button Hover Background', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item.pricing-box-not-loop .trydus-btn.btn-type-boxed:hover' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'btn_hover_animation',
			[
				'label' => __('Hover Animation', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
				// 'prefix_class' => 'elementor-animation-',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'button_border',
				'label' => __('Border', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-btn',
			]
		);

		$this->add_control(
			'button_border_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->add_responsive_control(
			'btn_width',
			[
				'label' => __('Button Width', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-btn' => 'width: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'button_spacing',
			[
				'label' => __('Button Spacing', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .trydus-btn' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __('Button Padding', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '15',
					'right' => '0',
					'bottom' => '15',
					'left' => '0'
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-btn.btn-type-boxed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_radius',
			[
				'label' => __('Button Radius', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '8',
					'right' => '8',
					'bottom' => '8',
					'left' => '8'
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-btn.btn-type-boxed' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bottom_text_stle',
			[
				'label' => __('Bottom Text', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bottom_text_typo',
				'label' => __('Bottom text typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-bottom-text span',
			]
		);
		$this->add_control(
			'bottom_text_color',
			[
				'label' => __('Bottom text color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-bottom-text span' => 'color: {{VALUE}}',
				]
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'box_styling',
			[
				'label' => __('Box style', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'box_bg_color',
			[
				'label' => __('Box Background', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item.pricing-box-not-loop' => 'background-color: {{VALUE}}',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label' => __('Focus Box Shadow', 'plugin-domain'),
				'selector' => '{{WRAPPER}} .trydus-pricing-item.focused',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 0,
							'vertical' => 32,
							'blur' => 54,
							'spread' => 0,
							'color' => 'rgba(22, 28, 45, 0.08)'
						]
					]
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __('Border', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-item.pricing-box-not-loop',
			]
		);
		$this->add_control(
			'box_border_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'box_radius',
			[
				'label' => __('Box Radius', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10'
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item.pricing-box-not-loop ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'box_paddin',
			[
				'label' => __('Box Padding', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item.pricing-box-not-loop' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
?>
		<div class="trydus-pricing-area <?php echo esc_attr($settings['content_align']) ?>">
			<div class="trydus-pricing-item pricing-box-not-loop <?php echo $settings['focused'] ?>">
				<span class="trydus-pricing-title"><?php echo $settings['title'] ?></span>
				<div class="trydus-price-wrap">
					<h2 class="trydus-price">
						<span class="price-currency"><?php echo $settings['price_currency'] ?></span><?php echo $settings['price'] ?><span class="trydus-pricing-duration"><?php echo $settings['price_duration'] ?></span>
					</h2>
					<?php if (!empty($settings['price_description'])) : ?>
						<span class="trydus-pricing-description"><?php echo $settings['price_description'] ?></span>
					<?php endif; ?>
				</div>
				<ul class="trydus-pricing-features">
					<?php
					if ($settings['feature_list']) :
						foreach ($settings['feature_list'] as  $feature) :
					?>
							<li class="class-feature-list">
							<?php \Elementor\Icons_Manager::render_icon($feature["feature_icon"], ['aria-hidden' => 'true']);
									echo $feature['feature_text'] 
							?>
							</li>

					<?php endforeach;
					endif; ?>
				</ul>
				<div class="trydus-btn-wrapper">
					<a class="trydus-btn btn-type-boxed <?php echo esc_attr(' elementor-animation-' . $settings['btn_hover_animation']) ?>" href="<?php echo $settings['button_url']['url'] ?>"><?php echo $settings['button_label'] ?> <?php \Elementor\Icons_Manager::render_icon($settings["btn_icon"], ['aria-hidden' => 'true']); ?></a>
				</div>
				<?php if ($settings['button_bottom_label']) : ?>
					<div class="trydus-pricing-bottom-text">
						<span><?php echo esc_html($settings['button_bottom_label']) ?></span>
					</div>
				<?php endif; ?>
			</div>
		</div>
<?php
	}
}
