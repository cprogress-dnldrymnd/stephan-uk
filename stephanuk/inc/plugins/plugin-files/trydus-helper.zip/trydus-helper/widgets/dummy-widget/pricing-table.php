<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusPriceTable extends \Elementor\Widget_Base
{

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'trydus-price-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('Trydus Pricing Loop', 'trydus-hp');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['trydus-addons'];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'price_tabs',
			[
				'label' => __('Price Tabs', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'first_tab_title',
			[
				'label' => __('First tab title', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Monthly '),
			]
		);
		$this->add_control(
			'second_tab_title',
			[
				'label' => __('Second tab title', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Yearly '),
			]
		);
		$this->add_control(
			'price_offer',
			[
				'label' => __('Offer text', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html('Save 20% '),
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'price_tables',
			[
				'label' => __('Price tables', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'only_features',
			[
				'label' => __('Show Only Features', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('No', 'trydus-hp'),
				'label_off' => __('yes', 'trydus-hp'),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$repeater->add_control(
			'focused',
			[
				'label' => __('Make it focsed', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Not Focused', 'trydus-hp'),
				'label_off' => __('Focused', 'trydus-hp'),
				'return_value' => 'focused',
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => __('Price title', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Personal',
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_currency',
			[
				'label' => __('Price Currency', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('$', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_monthly',
			[
				'label' => __('Montly Price', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('99', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_duration_monthly',
			[
				'label' => __('Montly Price Duration text', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('per month', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_subtitle_monthly',
			[
				'label' => __('Montly Price Subtitle', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('billed monthly', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'price_yearly',
			[
				'label' => __('Yearly  Price', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('180', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_duration_yearly',
			[
				'label' => __('Yearly Price Duration text', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('per year', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);
		$repeater->add_control(
			'price_subtitle_yearly',
			[
				'label' => __('Montly Price Yearly', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('billed Yearly', 'trydus-hp'),
				'condition'	=> [
					'only_features' => 'no',
				]
			]
		);

		$repeater->add_control(
			'features',
			[
				'label' => __('Features', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
			]
		);

		$repeater->add_control(
			'show_btn',
			[
				'label' => __('Show Button', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'trydus-hp'),
				'label_off' => __('Hide', 'trydus-hp'),
				'default'	=> 'true',
				'return_value' => 'true',
			]
		);
		$repeater->add_control(
			'btn_icon',
			[
				'label' => __('Button Icon', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => '',
					'library' => '',
				],
				'condition' => [
					'show_btn' => 'true',
				]
			]
		);
		$repeater->add_control(
			'button_label',
			[
				'label' => __('Button text', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Learn More',
				'condition' => [
					'show_btn' => 'true',
				]
			]
		);

		$repeater->add_control(
			'button_url',
			[
				'label' => __('Button URL', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::URL,
				'condition' => [
					'show_btn' => 'true',
				]
			]

		);
		$repeater->add_control(
			'btn_style',
			[
				'label' => __('Button  Style', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'boxed',
				'options' => [
					'inline'  => __('Inline', 'trydus-hp'),
					'boxed' => __('Boxed', 'trydus-hp'),
				],
			]
		);
		$repeater->add_control(
			'bottom_info',
			[
				'label' => __('Bottom Info', 'trydus-hp'),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'No credit card required',
			]
		);
		$this->add_control(
			'pricing_list',
			[
				'label' => __('Repeater List', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		/**
		 * Style tab
		 */
		$this->start_controls_section(
			'pricing_tabs_tyle',
			[
				'label' => __('Pricing Tabs', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tabs_title_typo',
				'label' => __('Title typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .first-tabs-title,{{WRAPPER}} .second-tabs-title',
			]
		);
		$this->add_control(
			'tabs_title_color',
			[
				'label' => __('Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .first-tabs-title, {{WRAPPER}} .second-tabs-title' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'offer_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'offer_typo',
				'label' => __('Offer typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-price-offer',
			]
		);
		$this->add_control(
			'offer_color',
			[
				'label' => __('Offer Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-price-offer' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'offer_bg_color',
			[
				'label' => __('Offer Background Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-price-offer' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'offer_padding',
			[
				'label' => __('Offer Text Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-price-offer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'offer_radius',
			[
				'label' => __('Offer Text Radius', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-price-offer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'Title_style',
			[
				'label' => __('Title', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => __('Title typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-title' => 'color: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'price_style',
			[
				'label' => __('Price', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_typo',
				'label' => __('Price typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-area .trydus-pricing-item .trydus-price h2',
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => __('Price Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-area .trydus-pricing-item .trydus-price h2' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'dura_style_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_dur_typo',
				'label' => __('Price Duration typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-price span.trydus-pricing-duration',
			]
		);

		$this->add_control(
			'duration_color',
			[
				'label' => __('Duration Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-duration' => 'color: {{VALUE}}',
				]
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'feature_style',
			[
				'label' => __('Feature', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'features_typo',
				'label' => __('Features typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-features',
			]
		);

		$this->add_control(
			'features_color',
			[
				'label' => __('Features Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-features' => 'color: {{VALUE}}',
				]
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'button_style',
			[
				'label' => __('Button', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => __('Button typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-btn-wrapper .trydus-btn',
			]
		);

		$this->add_control(
			'btn_color',
			[
				'label' => __('Button Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-btn-wrapper .trydus-btn' => 'color: {{VALUE}}',
				]
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label' => __('Button Background Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-btn-wrapper .trydus-btn' => 'background-color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __('Button Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'	=>	[
					'top' => '40px',
					'right' => '15px',
					'bottom' => '40px',
					'left' => '15px'
				],
				'selectors' => [
					'{{WRAPPER}} .trydus-btn.btn-type-boxed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bottom_text',
			[
				'label' => __('Bottom Info', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bottom_typo',
				'label' => __('typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .pricing-bottom-info',
			]
		);

		$this->add_control(
			'bottom_info_olor',
			[
				'label' => __('Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-bottom-info' => 'color: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'Box',
			[
				'label' => __('Box', 'trydus-hp'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'box_bg_color',
			[
				'label' => __('Box Background Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item' => 'background-color: {{VALUE}}',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label' => __('Foucsed Box Shadow', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .trydus-pricing-item.focused',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' => 'yes'
					],
					'box_shadow' => [
						'default' =>
						[
							'horizontal' => 3,
							'vertical' => 67,
							'blur' => 99,
							'spread' => 0,
							'color' => ' rgba(111, 118, 138, 0.16)'
						]
					]
				],

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'label' => __( 'box_border', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-pricing-item',
			]
		);
		$this->add_responsive_control(
			'box_radius',
			[
				'label' => __('Box Radius', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label' => __('Box Padding', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .trydus-pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$popular_post_key = array();
		$popular_meta_value_num = array();
		$settings = $this->get_settings_for_display();
?>

		<?php if ($settings['pricing_list']) : ?>
			<div class="trydus-pricing-area pricing-style-classic">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12 text-center">
							<div class="trydus-pricing-tabs">

								<span class="first-tabs-title"><?php echo $settings['first_tab_title'] ?></span>
								<div class="trydus-price-tabs-switcher">
									<div id="pricing-dynamic-deck--head">
										<a href="javascript:" class="btn-toggle active mx-3" data-pricing-trigger data-target="#trydus-dynamic-deck"><span class="round"></span></a>
									</div>
								</div>
								<span class="second-tabs-title"><?php echo $settings['second_tab_title'] ?></span>

								<span class="trydus-price-offer"><?php echo $settings['price_offer'] ?></span>
							</div>
						</div>
					</div>
					<div class="row justify-content-center" id="trydus-dynamic-deck" data-pricing-dynamic data-value-active="monthly">
						<?php
						$i = 0;
						foreach ($settings['pricing_list'] as  $pricing) :
							$i++;

						?>
							<div class="col-xl-4 col-md-6 trydus-pricing-item-wrap">
								<div class="trydus-pricing-item <?php echo $pricing['focused'] ?>">
									<!-- classic pricing -->
									<?php if ('no' == $pricing['only_features']) : ?>
										<div class="trydus-price-wrap">
											<span class="trydus-pricing-title"><?php echo $pricing['title'] ?></span>
											<div class="trydus-price trydus-price-monthly">
												<h2 class="dynamic-value" data-active="<?php echo $pricing['price_monthly'] ?>" data-monthly="<?php echo $pricing['price_monthly'] ?>" data-yearly="<?php echo $pricing['price_yearly'] ?>"><span class="price-currency"><?php echo esc_html( $pricing['price_currency'] ) ?></span></h2>
											<span class="trydus-pricing-duration dynamic-value" data-active="<?php echo $pricing['price_duration_monthly'] ?>" data-monthly="<?php echo $pricing['price_duration_monthly'] ?>" data-yearly="<?php echo $pricing['price_duration_yearly'] ?>"></span>
											<span class="price-subtitle dynamic-value" data-active="<?php echo esc_attr($pricing['price_subtitle_monthly'])?>" data-monthly="<?php echo esc_attr($pricing['price_subtitle_monthly'])?>" data-yearly="<?php echo esc_attr($pricing['price_subtitle_yearly'])?>"></span>
											</div>
										</div><!--  end of trydus-price-wrap  -->
									<?php else : ?>
										<div class="trydus-pricing-head-filler"></div>
									<?php endif; ?>
									<div class="trydus-pricing-features">
										<?php echo $pricing['features'] ?>
									</div>
									<!-- minimal pricing -->
									<?php if ('true' == $pricing['show_btn']) : ?>
										<div class="trydus-btn-wrapper">
											<a class="trydus-btn btn-type-<?php echo $pricing['btn_style'] ?> " href="<?php echo $pricing['button_url']['url'] ?>"><?php echo $pricing['button_label'] ?> <?php \Elementor\Icons_Manager::render_icon($pricing['btn_icon'], ['aria-hidden' => 'true']); ?></a>
										</div>
									<?php endif; ?>
									<?php if('' != $pricing['bottom_info']){printf('<span class="pricing-bottom-info">%s</span>', $pricing['bottom_info']);} ?>
								</div>
							</div>
						<?php endforeach;  ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
<?php
	}
}
