<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusServiceLoop extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'service-loop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Service Loop', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-settings';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'trydus-hp'),
            ]
        );
        $this->add_control(
            'service_style',
            [
                'label' => __('Select Style', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'home-8' => 'Consultation (Home 8)', 
                    'home-4' => 'Consultation (Home 4)', 
                ),
                'default' => 'home-8',
            ]
        );
        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );
        $this->add_control(
            'post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'col-md-12' => '1 Column',
                    'col-md-6' => '2 Column',
                    'col-md-4' => '3 Column',
                    'col-lg-3 col-md-6' => '4 Column',
                ),
                'default' => 'col-md-4',
            ]
        );
        $this->add_responsive_control(
            'bottom_spacing',
            [
                'label' => __('Bottom Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item ' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Show Excerpt', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
                'conditon' => [
                    'service_style!' => 'home-8',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_style',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item .service-title i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'conditon' => [
                    'service_style!' => 'home-8',
                ]
            ]
        );


        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item .service-title i' => 'color: {{VALUE}}',
                ],
                'conditon' => [
                    'service_style!' => 'home-8',
                ]
            ]
        );
        $this->add_control(
            'job_type_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control(
            'title_gap',
            [
                'label' => __('Title Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item .service-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Title Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-service-item .service-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item .service-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typ',
                'label' => __('Excerpt Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-service-item p',
            ]
        );


        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Excerpt Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_content_box_style',
            [
                'label' => __('Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-widget-service-item:hover',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-widget-service-item',
            ]
        );
        $this->add_responsive_control(
            'box_border_radius',
            [
                'label' => __('Box Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'Content box_padding',
            [
                'label' => __('Content Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-widget-service-item .service-content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();

        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'service',
        ));
?>
        <?php if ($the_query->have_posts()) : ?>
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                        <?php
                        $idd = get_the_ID();
                        $grid = '';
                        switch ($settings['post_grid']) {
                            case 'col-md-6':
                                $limit = 15;
                                $title = wp_trim_words(get_the_title(), 6, '...');
                                $grid = 'two-column';
                                break;
                            case 'col-md-4':
                                $limit = 15;
                                $title = wp_trim_words(get_the_title(), 9, '...');
                                $grid = 'three-column';
                                break;
                            case 'col-lg-3 col-md-6':
                                $limit = 15;
                                $title = wp_trim_words(get_the_title(), 6, '...');
                                $grid = 'three-column';
                                break;

                            default:
                                $limit = 30;
                                $title = get_the_title();
                                $grid = 'one-column';
                                break;
                        }

                        ?>
                        <div class="<?php echo $settings['post_grid'] ?>">
                            <a href="<?php the_permalink(); ?>" class="trydus-widget-service-item <?php echo esc_attr($grid . ' ' . $settings['service_style']) ?>">

                                <?php
                                if (has_post_thumbnail()) : ?>
                                    <div class="service-thumbnail-wrapper">
                                        <div class="service-thumbnail" aria-hidden="true" tabindex="-1">
                                            <?php
                                            the_post_thumbnail(
                                                'post-thumbnail',
                                                array(
                                                    'alt' => the_title_attribute(
                                                        array(
                                                            'echo' => false,
                                                        )
                                                    ),
                                                )
                                            );
                                            ?>
                                        </div>
                                    </div>
                                <?php
                                endif;
                                ?>

                                <div class="service-content-wrap">
                                    <?php

                                    echo '<h2 class="service-title d-flex align-items-center justify-content-between">';
                                    echo $title;

                                    if ('home-8' == $settings['service_style']) {
                                        echo '<i class="fas fa-arrow-right float-right"></i>';
                                    }

                                    echo '</h2>';
                                    ?>


                                    <?php if ('yes' == $settings['show_excerpt'] && 'home-8' != $settings['service_style']) {
                                        echo '<p>' . esc_html(wp_trim_words(get_the_excerpt(), $limit)) . '</p>';
                                    }
                                    ?>


                                </div>
                            </a>
                        </div>


                    <?php
                    endwhile;
                    wp_reset_postdata(); ?>
                </div>
            </div>
<?php
        endif;
    }
}
