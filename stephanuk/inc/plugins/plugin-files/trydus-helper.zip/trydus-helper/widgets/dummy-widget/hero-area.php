<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusHeroArea extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-hero-area';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Hero Area', 'trydus-hp' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-rollover';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'trydus-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'offer_label',
			[
				'label' => __( 'Offer label', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Offer', 'trydus-hp' ),
			]
		);
		$this->add_control(
			'offer',
			[
				'label' => __( 'Offer text', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '25% off for this month', 'trydus-hp' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => __( 'Title', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Promote your web app seamlessly with us', 'trydus-hp' ),
			]
		);



		$this->add_control(
			'image',
			[
				'label' => __( 'Choose App Image', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button',
			[
				'label' => __( 'Button', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'button_label',
			[
				'label' => __( 'Button Label', 'trydus-hp' ),
				'type' =>  \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'View demo',
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' => __( 'Button URL', 'trydus-hp' ),
				'type' =>  \Elementor\Controls_Manager::URL,
			]
		);
		$this->end_controls_section();

		/**
		 * Style tab
		 */
		$this->start_controls_section(
			'content',
			[
				'label' => __( 'General', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Section Background', 'trydus-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .trydus-hero-area',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'offer_typography',
				'label' => __( 'Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-offer-text',
			]
		);

		$this->add_control(
			'offer_color',
			[
				'label' => __( 'Ofer Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .trydus-offer-text' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __( 'Title Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-hero-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .trydus-hero-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'Button background',
				'label' => __( 'Section Background', 'trydus-hp' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} a.trydus-hero-btn',
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __( 'Button Padding', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	=>	[
					'top' => '40px',
					'right' => '15px',
					'bottom' => '40px',
					'left' => '15px'
				],
				'selectors' => [
					'{{WRAPPER}} a.trydus-hero-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$popular_post_key = array();
		$popular_meta_value_num =array();
		$settings = $this->get_settings_for_display();
		?>
		<div class="trydus-hero-area">
			<div class="container">
				<div class="row align-items-center text-center">
					<div class="col-12">
						<p class="trydus-offer-text"><span><?php echo $settings['offer_label'] ?></span><?php echo  $settings['offer'] ?></p>
						<h1 class="trydus-hero-title"><?php echo $settings['heading'] ?></h1>
						<a class="trydus-hero-btn" href="<?php echo $settings['button_url']['url'] ?>"><?php echo $settings['button_label'] ?></a>
						<div class="hero-image">
							<img src="<?php echo $settings['image']['url'] ?>" alt="hero image">
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

}

