<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusIntegratedIcons extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-Integrated-icons';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Integrated Icons', 'trydus-hp' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'trydus-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'icon_1',
			[
				'label' => __( 'Icon 1', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_2',
			[
				'label' => __( 'Icon 2', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_3',
			[
				'label' => __( 'Icon 3', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_4',
			[
				'label' => __( 'Icon 4', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_5',
			[
				'label' => __( 'Icon 5', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_6',
			[
				'label' => __( 'Icon 6', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);


		$this->add_control(
			'icon_7',
			[
				'label' => __( 'Icon 7', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'icon_8',
			[
				'label' => __( 'Icon 8', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Library icon color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trydus-integrated-icon-item svg' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_shadow',
				'label' => __( 'Icon Shadow', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .trydus-inline-icon-box-wrap .trydus-inline-icon-box-icon',
				'fields_options' =>
					[
						'box_shadow_type' =>
                        [
                            'default' =>'yes'
                        ],
						'box_shadow' => [
							'default' =>
								[
									'horizontal' => 10,
									'vertical' => 14,
									'blur' => 57,
									'spread' => 0,
									'color' => 'rgba(0, 0, 0, 0.09)'
								]
						]
					]
			]
		);



	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$popular_post_key = array();
		$popular_meta_value_num =array();
		$settings = $this->get_settings_for_display();
		?>
		<div class="trydus-integrated-icon-wrap">
			<?php for($i=1;$i<=8;$i++): ?>
			<div class="trydus-integrated-icon-item trydus-integrated-icon-<?php echo esc_html( $i ); ?>">
				<?php \Elementor\Icons_Manager::render_icon( $settings["icon_$i"], [ 'aria-hidden' => 'true' ] ); ?>
			</div>
			<?php endfor; ?>
		</div>
		<?php
	}

}

