<?php


/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusTestimonialStories extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'trydus-testimonial-stories';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trydus Testimonial Stories', 'trydus-hp' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'trydus-addons' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		/**
		 * Content tab
		 */
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'testimonial_title',
			[
				'label' => __( 'Testimonial title', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => '',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'quote_icon',
			[
				'label' => __( 'Select Quote Icon', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'solid',
				],
			]
        );
		$repeater->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'content', [
				'label' => __( 'Content', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'star',
			[
				'label' => __( 'Select star', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'1' => __( '1', 'trydus-hp' ),
					'2' => __( '2', 'trydus-hp' ),
					'3' => __( '3', 'trydus-hp' ),
					'4' => __( '4', 'trydus-hp' ),
					'5' => __( '5', 'trydus-hp' ),
				],
			]
		);

		$repeater->add_control(
			'company_icon',
			[
				'label' => __( 'Select Company Icon', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
        );
		$repeater->add_control(
			'name', [
				'label' => __( 'Name', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'David Mark' , 'trydus-hp' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'CEO of Lapsas' , 'trydus-hp' ),
				'show_label' => true,
			]
		);
		$this->add_control(
			'testimonial',
			[
				'label' => __( 'Repeater List', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slide_settings',
			[
				'label' => __( 'SLide Settings', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'prev_text',
			[
				'label' => __( 'Prev Text', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' => 'Prev Story',
			]
		);
		$this->add_control(
			'next_text',
			[
				'label' => __( 'Prev Text', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'fields' => $repeater->get_controls(),
				'default' =>  'Next Story',
			]
		);


		$this->end_controls_section();

		/**
		 * Style tab
		 */

		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'trydus-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_gap',
			[
				'label' => __( 'Title Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 45,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .trydus-testimonial-story-content .testimonial-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'star_gap',
			[
				'label' => __( 'Star Icon Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 25,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .trydus-testimonial-story-content .testimonial-star' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_gap',
			[
				'label' => __( 'Content Gap', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 25,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}  .trydus-testimonial-story-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __( 'Title Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-testimonial-story-content .testimonial-title',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Content Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-testimonial-story-content p',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cname_typography',
				'label' => __( 'CUstomer Name Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-testimonial-story-content .customer-name',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'ctitle_typography',
				'label' => __( 'Customer Title Typography', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-testimonial-story-content .customer-title',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_shadow',
				'label' => __( 'Customer Icon Shadow', 'trydus-hp' ),
				'selector' => '{{WRAPPER}} .trydus-testimonial-story-content .trydus-testimonial-company-icon',
				'fields_options' =>
				[
					'box_shadow_type' =>
					[
						'default' =>'yes'
					],
					'box_shadow' => [
						'default' =>
							[
								'horizontal' => -2,
								'vertical' => 16,
								'blur' => 27,
								'spread' => 0,
								'color' => 'rgba(111, 118, 138, 0.16)'
							]
					]
				]

			]
		);



		$this->end_controls_section();


	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if ( $settings['testimonial'] ) :?>
		<div class="trydus-testimonial-stories swiper-container">
			<div class="trydus-testimonial-storis-wrapper swiper-wrapper">
				<?php foreach($settings['testimonial'] as  $testimonial):  ?>
					<div class="trydus-testimonial-story swiper-slide">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<div class="trydus-testimonial-story-image">
										<span class="trydus-testimonial-quote-icon"><?php \Elementor\Icons_Manager::render_icon( $testimonial["quote_icon"], [ 'aria-hidden' => 'true' ] ); ?></span>
										<img src="<?php echo $testimonial['image']['url'] ?>" alt="<?php echo esc_attr__( 'Client testimonial', 'trydus-hp' ) ?>">
									</div>
								</div>
								<div class="col-md-6">
									<div class="trydus-testimonial-story-content">
										<h3 class="testimonial-title"><?php echo $settings['testimonial_title'] ?></h3>
										<div class="testimonial-star">
											<?php for($i=0;$i<$testimonial['star'];$i++): ?>
												<i class="fa fa-star"></i>
											<?php endfor; ?>
										</div>
										<p><?php echo esc_html( $testimonial['content'] ) ?></p>
										<div class="customer-meta">
											<span class="trydus-testimonial-company-icon"><?php \Elementor\Icons_Manager::render_icon( $testimonial["company_icon"], [ 'aria-hidden' => 'true' ] ); ?></span>
											<div class="customer-meta-content">
												<h4 class="customer-name"><?php echo $testimonial['name'] ?></h4>
												<span class="customer-title"><?php echo $testimonial['title'] ?></span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach;  ?>
			</div>
			<!-- Add Pagination -->
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-6 offset-md-6">
						<div class="swiper-navigation">
							<button class="swipe-prev" type="button"><?php echo $settings['prev_text'] ?></button>
							<button class="swipe-next" type="button"><?php echo $settings['next_text'] ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
		  <!-- Initialize Swiper -->
		  <script>
			  jQuery(document).ready(function(){
				var swiper = new Swiper('.trydus-testimonial-stories', {
					slidesPerView: 1,
					navigation: {
						nextEl: '.swipe-next',
						prevEl: '.swipe-prev',
					},

				});

			  })
		</script>
		<?php endif; ?>
		<?php
	}

}

