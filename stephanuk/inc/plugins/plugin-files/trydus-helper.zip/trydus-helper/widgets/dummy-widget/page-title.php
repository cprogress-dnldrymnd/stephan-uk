<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TrydusPageTitle extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-heading';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Page Title', 'trydus-hp');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Content tab
         */
        $this->start_controls_section(
            'Content',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'custom_title',
            [
                'label' => __('Custom Title', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'trydus-hp'),
                'label_off' => __('No', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'heading_label',
            [
                'label' => __('Heading text', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'condition' => [ 'custom_title' => 'yes' ]
            ]
        );
        $this->add_control(
            'heading_tags',
            [
                'label' => __('Title Tag', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'h3',
                'options' => [
                    'h1' => __('h1', 'trydus-hp'),
                    'h2' => __('h2', 'trydus-hp'),
                    'h3' => __('h3', 'trydus-hp'),
                    'h4' => __('h4', 'trydus-hp'),
                    'h5' => __('h5', 'trydus-hp'),
                    'h6' => __('h6', 'trydus-hp'),
                    'span' => __('span', 'trydus-hp'),
                    'p' => __('p', 'trydus-hp'),
                    'strong' => __('strong', 'trydus-hp'),
                ],
            ]
        );
        $this->add_control(
            'heading_url',
            [
                'label' => __('Heading URL', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'trydus-hp'),
                    'after' => __('After', 'trydus-hp'),
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_align',
            [
                'label' => __('Align', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'trydus-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'trydus-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'trydus-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'prefix_class' => 'content-align%s-',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();

        /**
         * Style tab
         */

        $this->start_controls_section(
            'title_typography',
            [
                'label' => __('title', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading .heading-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-heading .heading-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_gap',
            [
                'label' => __('Icon gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading .icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-heading .icon-after ' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading .heading-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-heading .heading-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-heading  ',
            ]
        );


        $this->add_control(
            'heading_color',
            [
                'label' => __('Heading Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'heading_border',
                'label' => __('Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-heading',
            ]
        );
        $this->add_responsive_control(
            'heading_padding',
            [
                'label' => __('Heading Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-heading' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'heading_shadow',
                'label' => __('Heading Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-heading',
                'fields_options' =>
                [
                    'box_shadow_type' =>
                    [
                        'default' => 'yes',
                    ],
                    'box_shadow' => [
                        'default' =>
                        [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 0,
                            'color' => 'rgba(128, 128, 128, 0.16)',
                        ],
                    ],
                ],
            ]
        );
        $this->add_control(
            'heading_hover_animation',
            [
                'label' => __('Hover Animation', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
                // 'prefix_class' => 'elementor-animation-',
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $popular_post_key = array();
        $popular_meta_value_num = array();
        $settings = $this->get_settings_for_display();
?>
        <div class="trydus-heading-wrapper ">
            <<?php echo $settings['heading_tags']; ?> class="trydus-heading <?php echo esc_attr(' elementor-animation-' . $settings['heading_hover_animation']) ?>">
            
            <?php if (!empty($settings['heading_url']['url'])) : ?>
                <a href="<?php echo $settings['heading_url']['url'] ?>">
                <?php endif; ?>
                <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                    <span class="icon-before  heading-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                <?php endif; ?>
                
                <?php do_action( 'trydus_before_page_title', '' ); ?>
                <?php echo $settings['custom_title'] == 'yes'? $settings['heading_label'] : apply_filters( 'trydus_page_title', get_the_title(  ), null ); ?>
                <?php do_action( 'trydus_after_page_title', '' ); ?>


                <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                    <span class="icon-after heading-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                <?php endif; ?>
                <?php if (!empty($settings['heading_url']['url'])) : ?>
                </a>
            <?php endif; ?>
            </<?php echo $settings['heading_tags']; ?>>
        </div>
<?php
    }
}
