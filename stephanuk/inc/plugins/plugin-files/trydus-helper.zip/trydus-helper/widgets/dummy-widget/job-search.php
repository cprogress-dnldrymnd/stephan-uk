<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class ShadeJobSearch extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-job-search';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Job Search', 'trydus-hp');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-search';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Content tab
         */
        $this->start_controls_section(
            'job_search',
            [
                'label' => __('General', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'submit_label',
            [
                'label' => __('Submit Label', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Search',
            ]
        );
        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();


        $job_type = trydus_cpt_taxonomy_slug_and_name(
            array(
                'taxonomy'          => 'job-type',
                'hide_empty'        => false,
            ),
            true
        );
        $job_location = trydus_cpt_taxonomy_slug_and_name(
            array(
                'taxonomy'          => 'job-location',
                'hide_empty'        => false,
            ),
            true
        );



?>
<div class="trydus-job-search-form">    
    <form method="GET" action="<?php echo get_post_type_archive_link('job'); ?>">
        <input class="trydus-job-search-input" type="search" name="search_key" id="search_key" placeholder="Job title or keyword">
        <select name="job-location" id="job-location" class="trydus-job-location">
            <option value=""><?php esc_html_e('City', 'trydus-hp') ?></option>
            <?php if (!empty($job_location)) {
                echo $job_location;
            } ?>
        </select>
        <button type="submit"><?php echo esc_html('Search'); ?></button>
    </form>
</div>

<?php
    }
}
