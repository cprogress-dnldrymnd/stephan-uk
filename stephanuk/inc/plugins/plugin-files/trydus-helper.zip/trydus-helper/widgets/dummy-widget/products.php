<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TrydusProducts extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-products';
    }


    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Products', 'shadpro-ts');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-products';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['shadpro-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('General', 'trydus-hp'),
            ]
        );
        $this->add_control(
            'limit',
            [
                'label' => __('Product Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 6,
            ]
        );
        $this->add_control(
            'column',
            [
                'label' => __('Columns', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 3,
            ]
        );
         $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Image Height', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .trydus-elm-products-wrap .woocommerce ul.products li.product .product-thumb-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'paginate',
            [
                'label' => __('Show Pagination?', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'trydus-hp'),
                'label_off' => __('No', 'trydus-hp'),
                'return_value' => true,
                'default' => false,
            ]
        );
        $this->add_control(
			'orderby',
			[
				'label' => __( 'orderby', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'  => __( 'date', 'trydus-hp' ),
					'id' => __( 'id', 'trydus-hp' ),
					'menu_order' => __( 'menu order', 'trydus-hp' ),
					'popularity' => __( 'popularity', 'trydus-hp' ),
					'rand' => __( 'rand', 'trydus-hp' ),
					'rating' => __( 'rating', 'trydus-hp' ),
					'title ' => __( 'title', 'trydus-hp' ),
				],
			]
		);


        $this->end_controls_section();
    }
    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {

        $settings = $this->get_settings();

?>
<div class="trydus-elm-products-wrap">
    <?php  echo do_shortcode( '[products limit="'.$settings['limit'].'" columns="'.$settings['column'].'" paginate="'.$settings['paginate'].'" orderby="'.$settings['orderby'].'"]' );?>
</div>
<?php
    }
}
