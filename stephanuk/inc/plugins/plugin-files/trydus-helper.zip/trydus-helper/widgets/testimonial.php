<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Trydus_Testimonail extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-testimonial';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Testimonial', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_content_s',
            [
                'label' => __('Content', 'trydus-hp'),
            ]
        );

        $this->add_control(
            't_style',
            [
                'label' => __('Border Style', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 't-style-1',
                'options' => [
                    't-style-1'  => __('Style 1', 'trydus-hp'),
                    't-style-2' => __('Style 2', 'trydus-hp'),
                ],
            ]
        );

        $this->add_responsive_control(
            't_post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '12' => '1 Column',
                    '6' => '2 Column',
                    '4' => '3 Column',
                    '3' => '4 Column',
                ),
                'default'            => 3,
                'tablet_default'     => 6,
                'mobile_default'     => 12,
                'condition' => [
                    't_style' => 't-style-2',
                ]
            ]
        );

        $this->add_control(
            't_enable_slider',
            [
                'label' => __('Slider On/OFF', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            't_video',
            [
                'label' => __('Video On/Off', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
 
        $this->add_control(
            'show_description',
            [
                'label' => __('Show Description', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
  
        $this->add_control(
            'show_name',
            [
                'label' => __('Show Name', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_position',
            [
                'label' => __('Show position', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            't_word_limit',
            [
                'label' => __('Testimonial Word Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
            ]
        );

        $this->add_control(
            'video_icon',
            [
                'label' => __('Video Icon', 'shadepro-ts'),
                'type'  => \Elementor\Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-play',
                    'library' => 'solid',
                ],
                'condition' => [
                    't_video' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        // SLIDER SETTINGS
        $this->start_controls_section(
            'qiery_settings',
            [
                'label' => __('Query Settings', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::TAB_CONTENT,
            ],
        );
        $this->add_control(
            'source',
            [
                'label'         => __('Source', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'archive' => 'Archive',
                    'manual_selection' => 'Manual Selection',
                    'related' => 'Related',
                ],
                'default' =>    'archive',
            ]
        );

        $this->add_control(
            'manual_selection',
            [
                'label'         => __('Manual Selection', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get specific template posts', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_slug_and_id('trydus_testimonial'),
                'default' =>    [],
                'condition' => [
                    'source' => 'manual_selection'
                ],
            ]
        );

        $this->start_controls_tabs(
            'include_exclude_tabs'
        );

        $this->start_controls_tab(
            'include_tabs',
            [
                'label' => __('Include', 'trydus-hp'),
                'condition' => [
                    'source!' => 'manual_selection'
                ],
            ]
        );

        $this->add_control(
            'include_by',
            [
                'label'         => __('Include by', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'label_block'   => true,
                'multiple'      => true,
                'options'       => [
                    'tags'  => 'Tags',
                    'category'  => 'Category',
                    'author' => 'Author',
                ],
                'default' =>    [],
                'condition' => [
                    'source!' => 'manual_selection'
                ],

            ]
        );
        $this->add_control(
            'include_categories',
            [
                'label'         => __('Include categories', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific category(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_taxonomy_slug_and_name('testimonial_category'),
                'default' =>    [],
                'condition' => [
                    'include_by' => 'category',
                    'source!' => 'related',
                    'source!' => 'manual_selection'
                ],

            ]
        );

        $this->add_control(
            'include_tags',
            [
                'label'         => __('Include Tags', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific tag(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_taxonomy_slug_and_name('testimonial_tag'),
                'default' =>    [],
                'condition' => [
                    'include_by' => 'tags',
                    'source!' => 'related',
                    'source!' => 'manual_selection'
                ],
            ]
        );

        $this->add_control(
            'include_authors',
            [
                'label'         => __('Include authors', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific tag(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_author_slug_and_id('trydus_testimonial'),
                'default' =>    [],
                'condition' => [
                    'include_by' => 'author',
                    'source!' => 'manual_selection'
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'exclude_tabs',
            [
                'label' => __('Exclude', 'trydus-hp'),
                'condition' => [
                    'source!' => 'manual_selection'
                ],
            ]
        );

        $this->add_control(
            'exclude_by',
            [
                'label'         => __('Exclude by', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'label_block'   => true,
                'multiple'      => true,
                'options'       => [
                    'tags'  => 'tags',
                    'category'  => 'Category',
                    'author' => 'Author',
                    'current_post' => 'Current Post',
                ],
                'default' =>    [],
                'condition' => [
                    'source!' => 'manual_selection',
                    'source!' => 'manual_selection'

                ],

            ]
        );

        $this->add_control(
            'exclude_categories',
            [
                'label'         => __('Exclude categories', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific category(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_taxonomy_slug_and_name('testimonial_category'),
                'default' =>    [],
                'condition' => [
                    'exclude_by' => 'category',
                    'source!' => 'related',
                    'source!' => 'manual_selection'
                ],

            ]
        );
        $this->add_control(
            'exclude_tags',
            [
                'label'         => __('Exclude Tags', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific tag(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_taxonomy_slug_and_name('testimonial_tag'),
                'default' =>    [],
                'condition' => [
                    'exclude_by' => 'tags',
                    'source!' => 'related',
                    'source!' => 'manual_selection'
                ],
            ]
        );

        $this->add_control(
            'exclude_authors',
            [
                'label'         => __('Exclude authors', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT2,
                'description'   => __('Get templates for specific tag(s)', 'trydus-hp'),
                'label_block'   => true,
                'multiple'      => true,
                'options'       => trydus_cpt_author_slug_and_id('trydus_testimonial'),
                'default' =>    [],
                'condition' => [
                    'exclude_by' => 'author',
                    'source!' => 'manual_selection'
                ],
            ]
        );


        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'testimonail_per_page',
            [
                'label' => __('Numbar Of Testimonial', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => '',
                'description' => 'user emty value show all posts'
            ]
        );
        
        $this->add_control(
            'orderby',
            [
                'label'         => __('Order By', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'date'   => 'Date',
                    'title'    => 'title',
                    'menu_order'    => 'Menu Order',
                    'rand'    => 'Random',
                ],
                'default' =>    'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label'         => __('Order', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'ASC'   => 'ASC',
                    'DESC'    => 'DESC',
                ],
                'default' =>    'DESC',
            ]
        );

        $this->end_controls_section();

        // SLIDER SETTINGS
        $this->start_controls_section(
            'slider_settings',
            [
                'label' => __('Slider Settings', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    't_enable_slider' => 'yes',
                ],
            ],
        );
        $this->add_control(
            'arrows',
            [
                'label' => __('Show arrows?', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );


        $this->add_control(
            'autoplay',
            [
                'label' => __('Auto Play?', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __('Infinite Loop', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'true',
            ]
        );

        $this->add_control(
            'autoplaytimeout',
            [
                'label' => __('Autoplay Timeout', 'trydus-hp'),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'default' => '5000',
                'options' => [
                    '1000'  => __('1 Second', 'trydus-hp'),
                    '2000'  => __('2 Second', 'trydus-hp'),
                    '3000'  => __('3 Second', 'trydus-hp'),
                    '4000'  => __('4 Second', 'trydus-hp'),
                    '5000'  => __('5 Second', 'trydus-hp'),
                    '6000'  => __('6 Second', 'trydus-hp'),
                    '7000'  => __('7 Second', 'trydus-hp'),
                    '8000'  => __('8 Second', 'trydus-hp'),
                    '9000'  => __('9 Second', 'trydus-hp'),
                    '10000' => __('10 Second', 'trydus-hp'),
                    '11000' => __('11 Second', 'trydus-hp'),
                    '12000' => __('12 Second', 'trydus-hp'),
                    '13000' => __('13 Second', 'trydus-hp'),
                    '14000' => __('14 Second', 'trydus-hp'),
                    '15000' => __('15 Second', 'trydus-hp'),
                ],
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __('Image', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label' => __('Image Width', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus--testimonial-thumb img'  => 'width: {{SIZE}}{{UNIT}};object-fit:cover;',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Image Height', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus--testimonial-thumb img'  => 'height: {{SIZE}}{{UNIT}}; object-fit:cover;',
                ],
            ]
        );

        $this->add_control(
			'object_position',
			[
				'label' => __( 'Object position', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'center center',
				'options' => [
					'center center'  => __( 'Center Center', 'trydus-hp' ),
					'center left' => __( 'center Left', 'trydus-hp' ),
					'center right' => __( 'center Right', 'trydus-hp' ),
					'top center' => __( 'Top Center', 'trydus-hp' ),
					'top left' => __( 'Top Left', 'trydus-hp' ),
					'top right' => __( 'Top Right', 'trydus-hp' ),
					'bottom center' => __( 'Bottom Center', 'trydus-hp' ),
					'bottom left' => __( 'Bottom Left', 'trydus-hp' ),
					'Bottom right' => __( 'Bottom Right', 'trydus-hp' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus--testimonial-thumb img'  => 'object-position: {{VALUE}};',
                ],
			]
        );

        
        
        $this->add_responsive_control(
            'image_radius',
            [
                'label' => __('Image Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--testimonial-thumb ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--testimonial-thumb ' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
  
        $this->add_responsive_control(
            'image_padding',
            [
                'label' => __('Image Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--testimonial-thumb ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--testimonial-thumb ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        //description
        $this->start_controls_section(
            'description',
            [
                'label' => __('Description', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'description_color',
            [
                'label' => __('Text Color', 'shadpro-ts'),
                'type'  => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus--tc P' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'   => 'description_typo',
                'label'  => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus--tc P',
            ]
        );

        $this->add_responsive_control(
            'description_margin',
            [
                'label' => __('Margin', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--tc P' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--tc P' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //name
        $this->start_controls_section(
            'name',
            [
                'label' => __('Name', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'name_color',
            [
                'label' => __('Text Color', 'shadpro-ts'),
                'type'  => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .t--name' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'   => 'name_typo',
                'label'  => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .t--name',
            ]
        );

        $this->add_responsive_control(
            'name_margin',
            [
                'label' => __('Margin', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .t--name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .t--name' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //postion
        $this->start_controls_section(
            'postion',
            [
                'label' => __('Position', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'postion_color',
            [
                'label' => __('Text Color', 'shadpro-ts'),
                'type'  => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .t-postion' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'   => 'postion_typo',
                'label'  => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .t-postion',
            ]
        );

        $this->add_responsive_control(
            'postion_margin',
            [
                'label' => __('Margin', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .t-postion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .t-postion' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Video box
        $this->start_controls_section(
            'video_box',
            [
                'label' => __('Video Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'videobg_color',
            [
                'label' => __('Background Color', 'shadpro-ts'),
                'type'  => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'video_icon_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox ' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-icon-videobox path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'video_icon_fill_color',
            [
                'label' => __('Icon Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox ' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-icon-videobox svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_position_toggle',
            [
                'label' => __('Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'label_off' => __('None', 'trydus-hp'),
                'label_on' => __('Custom', 'trydus-hp'),
                'return_value' => 'yes',
            ]
        );

        $this->start_popover();

        $this->add_responsive_control(
            'video_position_y',
            [
                'label' => __('Vertical', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'condition' => [
                    'video_position_toggle' => 'yes'
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox' => 'bottom: {{SIZE}}{{UNIT}}; transform:translate(-50%, 50%)',

                    'body.rtl {{WRAPPER}} .trydus-icon-videobox' => 'bottom: {{SIZE}}{{UNIT}}; transform: translatex(50%) translatey(50%)',
                ],
            ]
        );

        $this->add_responsive_control(
            'video_position_x',
            [
                'label' => __('Horizontal', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'condition' => [
                    'video_position_toggle' => 'yes'
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],

                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-icon-videobox' => 'left: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-icon-videobox' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_popover();

        $this->add_responsive_control(
            'video_padding',
            [
                'label' => __('Box Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; display: inline-flex; align-items:center; justify-content:center;',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'video_icon_size',
            [
                'label' => __('Icon Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-icon-videobox' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-icon-videobox svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'videobox_border_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-icon-videobox' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-icon-videobox' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Arrows
        $this->start_controls_section(
            'arrows_navigation',
            [
                'label' => __('Navigation - Arrow', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    't_enable_slider' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'arrow_position_toggle',
            [
                'label' => __('Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'label_off' => __('None', 'trydus-hp'),
                'label_on' => __('Custom', 'trydus-hp'),
                'return_value' => 'yes',
            ]
        );

        $this->start_popover();

        $this->add_responsive_control(
            'arrow_position_y',
            [
                'label' => __('Vertical', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%','px'],
                'condition' => [
                    'arrow_position_toggle' => 'yes'
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus--testimonial .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_position_x',
            [
                'label' => __('Horizontal', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'condition' => [
                    'arrow_position_toggle' => 'yes'
                ],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--testimonial .owl-nav' => 'right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--testimonial .owl-nav' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'arrow_position_right_gap',
            [
                'label' => __('Prev Aarrow Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'condition' => [
                    'arrow_position_toggle' => 'yes'
                ],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 2000,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--testimonial .owl-nav .owl-prev' => 'margin-right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--testimonial .owl-nav .owl-prev' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_popover();

        $this->start_controls_tabs('_tabs_arrow');

        $this->start_controls_tab(
            '_tab_arrow_normal',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .trydus--testimonial .owl-nav i' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}} .trydus--testimonial .owl-nav svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            '_tab_arrow_hover',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                     '{{WRAPPER}} .trydus--testimonial .owl-nav *:hover i' => 'color: {{VALUE}};',
                     '{{WRAPPER}} .trydus--testimonial .owl-nav *:hover svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
       
        $this->end_controls_section();

        //content box
        $this->start_controls_section(
            'content_box',
            [
                'label' => __('Content Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            't_contnet_box',
            [
                'label' => __('Horizontal Align', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'trydus-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('center', 'trydus-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'trydus-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                   '{{WRAPPER}} .trydus--tc' => 'text-align: {{VALUE}}',
                ],
                'default' => 'left',
                'toggle' => true,
            ]
        );

        $this->add_control(
            't_contnet_box_v',
            [
                'label' => __('Vertical Align', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'start' => [
                        'title' => __('Top', 'trydus-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('Middle', 'trydus-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'end' => [
                        'title' => __('Bottom', 'trydus-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $this->add_responsive_control(
            't_contnet_box_margin',
            [
                'label' => __('Margin', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus--tc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus--tc' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();
        $include_categories = [];
        $exclude_tags = [];
        $include_tags = '';
        $include_authors = '';
        $exclude_categories = [];
        $exclude_authors = '';
        $current_post_id = '';
        $t_video   = $settings['t_video'];
        $t_version = $settings['t_enable_slider'];
        $testimonail_of_page = !empty($settings['testimonail_per_page']) ? $settings['testimonail_per_page'] : -1;
        $t_post_grid_desktop = $settings['t_post_grid'];
        $t_post_grid_tablet  = $settings['t_post_grid_tablet'];
        $t_post_grid_mobile  = $settings['t_post_grid_mobile'];
        $t_post_grid = sprintf('col-lg-%s col-md-%s col-%s', esc_attr($t_post_grid_desktop), esc_attr($t_post_grid_tablet), esc_attr($t_post_grid_mobile));

        //this code slider option
        $testimonial_extraSetting = array(
            'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
            'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
            'nav'  => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
            'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
            'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
        );
        $jasondecode = wp_json_encode($testimonial_extraSetting);



        if ( 0 != count($settings['include_categories'])) {
            $include_categories['tax_query'] = [
                'taxonomy' => 'testimonial_category',
                'field'    => 'slug',
                'terms'    => $settings['include_categories'],
            ];
        }

        if ( 0 != count($settings['include_tags'])) {
            $include_tags = implode(',', $settings['include_tags']);
        }


        if ( 0 != count($settings['include_authors'])) {
            $include_authors = implode(',', $settings['include_authors']);
        }
        if ( 0 != count($settings['exclude_categories'])) {
            $exclude_categories['tax_query'] = [
                'taxonomy' => 'testimonial_category',
                'operator' => 'NOT IN',
                'field'    => 'slug',
                'terms'    => $settings['exclude_categories'],
            ];
        }

        if ( 0 != count($settings['exclude_tags'])) {
            $exclude_tags['tax_query'] = [
                'taxonomy' => 'testimonial_tag',
                'operator' => 'NOT IN',
                'field'    => 'slug',
                'terms'    => $settings['exclude_tags'],
            ];
        }

        if ( 0 != count($settings['exclude_authors'])) {
            $exclude_authors = implode(',', $settings['exclude_authors']);
        }

        if (in_array('current_post', $settings['exclude_by'])) {
            $current_post_id = get_the_ID();
        }


        // var_dump($settings['exclude_categories']);
        if ('related' == $settings['source'] && is_single() && 'post' == get_post_type()) {
            $related_categories = get_the_terms(get_the_ID(), 'category');
            $related_cats = [];
            foreach ($related_categories as $related_cat) {
                $related_cats[] = $related_cat->slug;
            }
            $trydus_tp = new WP_Query(array(
                'posts_per_page' => $testimonail_of_page,
                'post_type' => 'trydus_testimonial',
                'orderby' => $settings['orderby'],
                'order' => $settings['order'],
                'post__not_in' => array($current_post_id),
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'testimonial_category',
                        'operator' => 'IN',
                        'field'    => 'slug',
                        'terms'    => $related_cats,
                    ),
                ),
            ));
        } elseif ('manual_selection' == $settings['source']) {
            $trydus_tp = new WP_Query(array(
                'posts_per_page' => $testimonail_of_page,
                'post_type' => 'trydus_testimonial',
                'orderby' => $settings['orderby'],
                'order' => $settings['order'],
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                'post__in' => ( 0 != count($settings['manual_selection'])) ? $settings['manual_selection'] : array(),
            ));
        } else {
            $trydus_tp = new WP_Query(array(
                'posts_per_page' => $testimonail_of_page,
                'post_type' => 'trydus_testimonial',
                'orderby' => $settings['orderby'],
                'order' => $settings['order'],
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                'testimonial_tag' => ( 0 != count($settings['include_tags'])) ? $include_tags : '',
                'post__not_in' => array($current_post_id),
                'author' => ( 0 != count($settings['include_authors'])) ? $include_authors : '',
                'author__not_in' => ( 0 != count($settings['exclude_authors'])) ? $exclude_authors : '',
                'tax_query' => array(
                    'relation' => 'AND',
                    ( 0 != count($settings['exclude_tags'])) ? $exclude_tags : '',
                    ( 0 != count($settings['exclude_categories'])) ? $exclude_categories : '',
                    ( 0 != count($settings['include_categories'])) ? $include_categories : '',
                ),
            ));
        }

        if (('yes' == $t_version)) {
            $this->add_render_attribute('testimonail_version', 'class', array('trydus--testimonial','owl-carousel', 't-style' ));
            $this->add_render_attribute('testimonail_version', 'data-settings', $jasondecode);
        } else {
            $this->add_render_attribute('testimonail_version', 'class', array( $settings['t_style'], 'row' ));
        } ?>
        <div class="trydus--testimonial-wraper">


			<div <?php echo $this->get_render_attribute_string('testimonail_version'); ?> >
				<?php
                    while ($trydus_tp->have_posts()): $trydus_tp->the_post();
        $content = ($settings['t_word_limit']['size']) ? wp_trim_words(get_the_excerpt(), $settings['t_word_limit']['size'], '...') : get_the_excerpt(); ?>
                    <?php if ('t-style-1' == $settings['t_style']): ?>
                    <div class="col-12">
                        <div class="trydus--testimonial-item">
                            <div class="row">
                                <div class="col-lg-6 d-flex align-items-<?php echo $settings['t_contnet_box_v'] ?> order-lg-1 order-md-2 order-2">
                                    <div class="trydus--testimonial-content">
                                        <div class="trydus--tc">
                                            <p><?php echo esc_html($content); ?></p>
                                            <h5 class="t--name"><?php the_title(); ?></h5>
                                            <?php if (function_exists("the_field")): ?>
                                                <span class="t-postion"><?php echo get_field('position'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-6 order-lg-2 order-md-1 order-1">
                                    <?php if (has_post_thumbnail()): ?>
                                        <div class="trydus--testimonial-thumb">
                                            <?php the_post_thumbnail(); ?>

                                            <?php if ($t_video && function_exists("the_field")): ?>
                                                <a class="trydus-icon-videobox trydus-popup-youtube" href="<?php echo get_field('video_url'); ?>" >
                                                    <?php \Elementor\Icons_Manager::render_icon($settings['video_icon'], ['aria-hidden' => 'true']); ?>
                                                </a>
                                            <?php endif ?>
                                            
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    
                        <div class="<?php echo $t_post_grid; ?>">
                                <div class="trydus--testimonial-item">
                                <?php if (has_post_thumbnail()): ?>
                                    <div class="trydus--testimonial-thumb">
                                        <?php the_post_thumbnail(); ?>

                                        <?php if ($t_video && function_exists("the_field")): ?>
                                            <a class="trydus-icon-videobox trydus-popup-youtube" href="<?php echo get_field('video_url'); ?>" >
                                                <?php \Elementor\Icons_Manager::render_icon($settings['video_icon'], ['aria-hidden' => 'true']); ?>
                                            </a>
                                        <?php endif ?>
                                        
                                    </div>
                                <?php endif; ?>
                                <div class="trydus--testimonial-content">
                                    <div class="trydus--tc">

                                        <?php if( 'yes' == $settings['show_description'] ): ?>
                                        <p><?php echo esc_html($content); ?></p>
                                        <?php endif; ?>
                                        
                                        <?php if( 'yes' == $settings['show_name'] ): ?>
                                        <h5 class="t--name"><?php the_title(); ?></h5>
                                        <?php endif; ?>
                                        
                                        <?php if( 'yes' == $settings['show_position'] ): ?>
                                            <?php if (function_exists("the_field")): ?>
                                                <span class="t-postion"><?php echo get_field('position'); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
				<?php endwhile;
        wp_reset_query(); ?>
			</div>

		</div>
		<?php
    }
}
