<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

class Trydus_Btn extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-btn';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Button', 'trydus-hp');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-button';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Content tab
         */
        $this->start_controls_section(
            'button',
            [
                'label' => __('Button', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_lightbox',
            [
                'label' => __('Youtube Video Popup', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'trydus-hp'),
                'label_off' => __('No', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'button_label',
            [
                'label' => __('Button text', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Learn More',
            ]
        );

        $this->add_control(
            'button_url',
            [
                'label' => __('Button URL', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'trydus-hp'),
                    'after' => __('After', 'trydus-hp'),
                ],
            ]
        );

        $this->add_responsive_control(
            'button_align',
            [
                'label' => __('Align', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'trydus-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'trydus-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'trydus-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'prefix_class' => 'content-align%s-',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();

        /**
         * Style tab
         */
        $this->start_controls_section(
            'icon_style',
            [
                'label' => __('Icon', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'icon_style_tabs'
        );
        
        $this->start_controls_tab(
            'icon_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .btn-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-btn .btn-icon path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_fill_color',
            [
                'label' => __('Icon Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .btn-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );
  
        $this->add_responsive_control(
            'icon_bg_color',
            [
                'label' => __('Icon Background', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .btn-icon' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_gap',
            [
                'label' => __('Icon gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-btn .icon-after ' => 'margin-left: {{SIZE}}{{UNIT}};',
                
                    'body.rtl {{WRAPPER}} .trydus-btn .icon-before' => 'margin-left: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-btn .icon-after ' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover .btn-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-btn:hover .btn-icon path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_fill_color_hover',
            [
                'label' => __('Icon Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover .btn-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_bg_color_hover',
            [
                'label' => __('Icon Background', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover .btn-icon' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_gap_hover',
            [
                'label' => __('Icon gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover .icon-before' => 'transform: translatex( -{{SIZE}}{{UNIT}} );',
                    '{{WRAPPER}} .trydus-btn:hover .icon-after ' => 'transform: translatex( {{SIZE}}{{UNIT}} );',
                 
                    'body.rtl {{WRAPPER}} .trydus-btn:hover .icon-before' => 'transform: translatex( {{SIZE}}{{UNIT}} );',
                    'body.rtl {{WRAPPER}} .trydus-btn:hover .icon-after ' => 'transform: translatex( -{{SIZE}}{{UNIT}} );',
                ],
            ]
        );

        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .btn-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-btn .btn-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_box_size',
            [
                'label' => __('Icon Box Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn .btn-icon' => 'width: {{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}; display:inline-flex; align-items:center;justify-content:center',
                ],
            ]
        );

        $this->add_control(
            'play_icon_bg',
            [
                'label' => __('Background Color', 'elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn-wrapper .btn-icon' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'play_icon_box_size',
            [
                'label' => __('Icon Box Size', 'elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn-wrapper .btn-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_box_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn-wrapper .btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-btn-wrapper .btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
                'condition' => [
                    'enable_lightbox' => 'boxed',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'button_style',
            [
                'label' => __('Button', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typography',
                'label' => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-btn',
            ]
        );

        $this->start_controls_tabs(
            'button_style_tabs'
        );
        
        $this->start_controls_tab(
            'button_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'boxed_btn_color',
            [
                'label' => __('Button Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' =>  '#fff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'boxed_btn_background',
            [
                'label' => __('Background Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' =>  '#233AFF',
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-btn',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'label' => __('Button Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-btn',
            ]
        );

        $this->add_responsive_control(
            'button_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-btn' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        

        $this->add_control(
            'btn_hover_color',
            [
                'label' => __('Button Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_background',
            [
                'label' => __('Background Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'disable_hover_effect',
            [
                'label' => __('Disable Deafault Hover Effect', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'trydus-hp'),
                'label_off' => __('No', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_hover_border',
                'label' => __('Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-btn:hover',
            ]
        );

        $this->add_control(
            'btn_hover_animation',
            [
                'label' => __('Hover Animation', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_hover_shadow',
                'label' => __('Button Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-btn:hover',
            ]
        );

        $this->add_responsive_control(
            'button_hover_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
       
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Button Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '20',
                    'right' => '40',
                    'bottom' => '15',
                    'left' => '40',
                ],
                'selectors' => [
                    '{{WRAPPER}} .trydus-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-btn' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'lightbox_content_animation',
            [
                'label' => __('Popup Animation', 'elementor'),
                'type' => \Elementor\Controls_Manager::ANIMATION,
                'frontend_available' => true,
                'condition' => [
                    'enable_lightbox' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }



    

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $popular_post_key = array();
        $popular_meta_value_num = array();
        $settings = $this->get_settings_for_display();
        $target = $settings['button_url']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['button_url']['nofollow'] ? ' rel="nofollow"' : '';
        
        $lightbox_options = [
            'type' => 'video',
            'videoType' => 'youtube',
            'url' => \Elementor\Embed::get_embed_url( $settings['button_url']['url'] ),
            'modalOptions' => [
                'id' => 'elementor-lightbox-' . $this->get_id(),
                'entranceAnimation' => $settings['lightbox_content_animation'],
                'entranceAnimation_tablet' => $settings['lightbox_content_animation_tablet'],
                'entranceAnimation_mobile' => $settings['lightbox_content_animation_mobile'],
                'videoAspectRatio' => '169',
            ],
        ];
        $this->add_render_attribute( 'trydus-btn-lightbox', [
            'data-elementor-open-lightbox' => 'yes',
            'data-elementor-lightbox' => wp_json_encode( $lightbox_options ),
        ] );
      
?>
        <div class="trydus-btn-wrapper enable-icon-box-<?php echo esc_attr( $settings['enable_lightbox'] ) ?>">
            <?php if ('yes' != $settings['enable_lightbox']) : ?>
                <a class="trydus-btn  d-inline-flex align-items-center <?php printf('%s disable-default-hover-%s', esc_attr('elementor-animation-' . $settings['btn_hover_animation']), $settings['disable_hover_effect']) ?>" <?php printf('href="%s" %s %s', $settings['button_url']['url'], $nofollow, $target) ?>>
            <?php else : ?>
                <div class="trydus-btn d-inline-flex align-items-center <?php printf('%s', esc_attr('elementor-animation-' . $settings['btn_hover_animation'])) ?>" <?php echo $this->get_render_attribute_string( 'trydus-btn-lightbox' ); ?>>
            <?php endif; ?>

                    <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                        <span class="icon-before  btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>

                    <?php echo $settings['button_label'] ?>

                    <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                        <span class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>
                    <?php if ('yes' != $settings['enable_lightbox']) : ?>
                </a>
            <?php else : ?>
            </div>
            <?php endif; ?>
    </div>
<?php
    }
}
