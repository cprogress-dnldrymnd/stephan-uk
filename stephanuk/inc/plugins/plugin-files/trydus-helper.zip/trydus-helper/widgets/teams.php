<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Trydus_Teams extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-teams';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Teams', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_general',
            [
                'label' => __('Layout Settings', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
           
            ]
        );

        
		$this->add_control(
			'team_style',
			[
				'label' => __( 'Border Style', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => __( 'Style 1', 'trydus-hp' ),
					'2' => __( 'Style 2', 'trydus-hp' ),
				],
			]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts per page', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
            ]
        );


        $this->add_responsive_control(
            'post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '12' => '1 Column',
                    '6' => '2 Column',
                    '4' => '3 Column',
                    '3' => '4 Column',
                ),
                'default'            => 3,
                'tablet_default'     => 6,
                'mobile_default'     => 12,
            ]
        );

        $this->add_responsive_control(
            'column_gap',
            [
                'label' => __('Column Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-team-item-wrap' => 'padding: 0 {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_description',
            [
                'label' => __('Description', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'show_desc',
            [
                'label' => __('Show Description', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        
        $this->add_control(
            'desc_limit',
            [
                'label' => __('Excerpt Word Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'condition' => [
                    'show_desc' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'image_style',
            [
                'label' => __('Image', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
                
        $this->add_responsive_control(
            'image_width',
            [
                'label' => __( 'Image width', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-image img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team-style-2 .member-image' => 'flex: 0 0 {{SIZE}}{{UNIT}};',
                ],
                'size_units' => ['px', '%'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __( 'Image Height', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-image img' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'size_units' => ['px', '%'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
            ]
        );

        $this->add_responsive_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item .member-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                    'body.rtl {{WRAPPER}} .trydus-team-item .member-image img' => 'border-radius:{{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'image_padding',
            [
                'label' => __('Image Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item .member-image ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item .member-image ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'member_name',
				'label' => __('Name typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .member-name',
			]
        );
        $this->add_control(
			'name_color',
			[
				'label' => __('Name Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .member-name' => 'color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __( 'Name Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .member-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->add_control(
			'position_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'member_postion',
				'label' => __('Postion typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .team-position',
			]
        );
        $this->add_control(
			'postion_color',
			[
				'label' => __('Postion Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-position' => 'color: {{VALUE}}',
				]
			]
        );

        $this->add_responsive_control(
            'position_spacing',
            [
                'label' => __( 'Position Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .team-position' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_desc' => 'yes',
                ]
			]
        );

        $this->add_control(
			'description_divide',
			[
                'type' => \Elementor\Controls_Manager::DIVIDER,
                'condition' => [
                    'show_desc' => 'yes',
                ]
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'member_desc',
				'label' => __('Description typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .team-description',
                'condition' => [
                    'show_desc' => 'yes',
                ]
			]
        );
        $this->add_control(
			'dexc_color',
			[
				'label' => __('Description Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-description' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'show_desc' => 'yes',
                ]
			]
        );
        
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Content Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item .member-details ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item .member-details ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'apply_style',
            [
                'label' => __('Apply Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition'	=> [
					'show_apply' => 'yes',
				]
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'apply_title',
				'label' => __('Apply Title typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .team-apply-card h4',
			]
        );
        $this->add_control(
			'apply_title_color',
			[
				'label' => __('Apply Title Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-apply-card h4' => 'color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
            'apply_title_spacing',
            [
                'label' => __( 'Apply Title Spacing', 'trydus-hp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .team-apply-card h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ]
            ]
        );
        $this->add_control(
			'apply_link_divide',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'apply_link_typo',
				'label' => __('Link %ext Typography', 'trydus-hp'),
				'selector' => '{{WRAPPER}} .team-apply-card  a',
			]
        );
        $this->add_control(
			'link_color',
			[
				'label' => __('Link Color', 'trydus-hp'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-apply-card  a' => 'color: {{VALUE}}',
				]
			]
        );

        $this->add_responsive_control(
            'apply_padding',
            [
                'label' => __('Apply Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .team-apply-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .team-apply-card' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
     
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_box_style',
            [
                'label' => __('Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'box_style_tabs'
        );
        
        $this->start_controls_tab(
            'box_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'box_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-team-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-team-item',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-team-item',
            ]
        );

        $this->add_control(
            'hide_last_item_border',
            [
                'label' => __('Hide Last Item Border?', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-wrap:last-child .trydus-team-item' => 'border: none!important',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'box_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'box_hover_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'defautl' => '#233aff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-team-item:hover:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_hover_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_hover_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-team-item:hover',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_hover_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-team-item:hover ',
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_margin',
            [
                'label' => __('Box Margin', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-team-item ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-team-item ' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();        
        $post_grid_desktop = $settings['post_grid'];
        $post_grid_tablet  = $settings['post_grid_tablet'];
        $post_grid_mobile  = $settings['post_grid_mobile'];
        $post_grid = sprintf('col-lg-%s col-md-%s col-%s', esc_attr($post_grid_desktop), esc_attr($post_grid_tablet), esc_attr($post_grid_mobile)); 


        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'team',
            'order' => 'ASC',
        ));
?>
        <div class="container-fluid">
            <div class="row trydus-teams-wrap justify-content-center">
                <?php while ($the_query->have_posts()) : $the_query->the_post();
                    $idd = get_the_ID();
                    $description = ( isset($settings['desc_limit']['size']) ) ? wp_trim_words(get_the_excerpt(), $settings['desc_limit']['size'], '...') : get_the_excerpt();
                ?>
                    <div class="<?php printf( '%s team-style-%s', esc_attr($post_grid), $settings['team_style'] ); ?> trydus-team-item-wrap">
                        <a href="<?php echo esc_url(get_the_permalink()) ?>" class="trydus-team-item">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="member-image">
                                    <?php echo get_the_post_thumbnail($idd, 'large') ?>
                                </div>
                            <?php endif; ?>
                            <div class="member-details">
                                <h4 class="member-name"><?php echo get_the_title() ?></h4>
                                <?php if ( function_exists("the_field")): ?>
                                    <span class="team-position"><?php the_field('position'); ?></span>
                                <?php endif ?>
                                <?php if( 'yes' ==  $settings['show_desc'] ): ?>
                               <div class="team-description">
                                   <?php echo esc_html( $description ) ?>
                               </div>
                               <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php
                endwhile;
                wp_reset_postdata(); ?>

        </div>

<?php
    }
}
