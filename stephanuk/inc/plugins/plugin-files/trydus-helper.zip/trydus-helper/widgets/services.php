<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Trydus_Services extends \Elementor\Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-service';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Services', 'trydus-hp');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-settings';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls()
    {
        $this->start_controls_section(
            'section_general',
            [
                'label' => __('General', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
			'service_style',
			[
				'label' => __( 'Border Style', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => __( 'Style 1', 'trydus-hp' ),
					'2' => __( 'Style 2', 'trydus-hp' ),
					'3' => __( 'Style 3', 'trydus-hp' ),
				],
			]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Post to show', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );

        
        $this->add_responsive_control(
            'post_grid',
            [
                'label' => __('Post grid', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '12' => '1 Column',
                    '6' => '2 Column',
                    '4' => '3 Column',
                    '3' => '4 Column',
                ),
                'default'            => 3,
                'tablet_default'     => 6,
                'mobile_default'     => 12,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'         => __('Order By', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'date'   => 'Date',
                    'title'    => 'title',
                    'menu_order'    => 'Menu Order',
                    'rand'    => 'Random',
                ],
                'default' =>    'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label'         => __('Order', 'trydus-hp'),
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'ASC'   => 'ASC',
                    'DESC'    => 'DESC',
                ],
                'default' =>    'DESC',
            ]
        );

        $this->add_responsive_control(
            'column_gap',
            [
                'label' => __('Column Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-wrap' => 'padding: 0 {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'row_gap',
            [
                'label' => __('Row Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-wrap' => 'margin: 0 0 {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_image',
            [
                'label' => __('Image', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_control(
            'show_shape',
            [
                'label' => __('Show Shape', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();
   
        $this->start_controls_section(
            'section_title',
            [
                'label' => __('Title', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title_icon',
            [
                'label' => __('Choose Icon', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'title_limit',
            [
                'label' => __('Title Word Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Show Excerpt', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_limit',
            [
                'label' => __('Excerpt Word Limit', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'conditon' => [
                    'show_excerpt' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_btn',
            [
                'label' => __('Readmore', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_readmore',
            [
                'label' => __('Readmore button', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'yes',

            ]
        );

        $this->add_control(
            'readmore_text',
            [
                'label' => __('Readmore text', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('READ MORE', 'trydus-hp'),
                'conditon' => [
                    'show_readmore' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'conditon' => [
                    'show_readmore' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'trydus-hp'),
                    'after' => __('After', 'trydus-hp'),
                ],
                'conditon' => [
                    'show_readmore' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
            'button_align',
            [
                'label' => __('Align', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'trydus-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'trydus-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'trydus-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'prefix_class' => 'content-align%s-',
                'toggle' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __('Image', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'image_style_tabs'
            
        );
        
        $this->start_controls_tab(
            'image_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'svg_line_color',
            [
                'label' => __('SVG Line Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail svg path' => 'stroke: {{VALUE}}',
                ],
                'description' => __( 'Note: This color only work with svg. If your featured image is svg thent it will work.', 'trydus-hp' ),
                'condition' => [
                    'service_style' => '1',
                ]
                
            ]
        );

        $this->add_control(
            'svg_fill_color',
            [
                'label' => __('SVG Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail svg path' => 'fill: {{VALUE}}',
                ],
                'description' => __( 'Note: This color only work with svg. If your featured image is svg thent it will work.', 'trydus-hp' ),
                'condition' => [
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_control(
            'shape_bg_color',
            [
                'label' => __('Shape Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail .image-shape' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
            'shape_radius',
            [
                'label' => __('Shape Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail .image-shape' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-thumbnail .image-shape' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );
   
        $this->add_responsive_control(
            'image_radius',
            [
                'label' => __('Image Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'image_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        $this->add_control(
            'svg_hover_line_color',
            [
                'label' => __('SVG Line Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail svg path' => 'stroke: {{VALUE}}',
                ],
                'description' => __( 'Note: This color only work with svg. If your featured image is svg thent it will work.', 'trydus-hp' ),
                'condition' => [
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_control(
            'svg_hover_fill_color',
            [
                'label' => __('SVG Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail svg path' => 'fill: {{VALUE}}',
                ],
                'description' => __( 'Note: This color only work with svg. If your featured image is svg thent it will work.', 'trydus-hp' ),
                'condition' => [
                    'service_style' => '1',
                ]
            ]
        );
        
        $this->add_control(
            'shape_hover_color',
            [
                'label' => __('Shape Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover  .service-thumbnail .image-shape' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
            'shape_hover_radius',
            [
                'label' => __('Shape Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail .image-shape' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail .image-shape' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );
        $this->add_responsive_control(
            'image_radius_hover',
            [
                'label' => __('Image Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item:hover .service-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
            'image_style_divider',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => __('Image Width', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail svg, {{WRAPPER}} .service-thumbnail img'  => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Image Height', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail svg, {{WRAPPER}} .service-thumbnail img'  => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'shape_size',
            [
                'label' => __('Shape Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail .image-shape'  => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
            'shape_x_position',
            [
                'label' => __('Shape Y Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail .image-shape'  => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
            'shape_y_position',
            [
                'label' => __('Shape X Position', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail .image-shape'  => 'left: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-thumbnail .image-shape'  => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_shape' => 'yes',
                    'service_style' => '1',
                ]
            ]
        );

        $this->add_responsive_control(
            'image_padding',
            [
                'label' => __('Image Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-thumbnail ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-thumbnail ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_style',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Title Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item .service-title',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typ',
                'label' => __('Excerpt Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item p',
            ]
        );

        $this->start_controls_tabs(
            'content_style_tabs'
        );
        
        $this->start_controls_tab(
            'content_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_icon_line_color',
            [
                'label' => __('Title Icon Line Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title-icon svg path' => 'stroke: {{VALUE}}',
                ],
                'condition' => [
                    'title_icon!' => '',
                ]
                
            ]
        );

        $this->add_control(
            'title_icon_fill_color',
            [
                'label' => __('SVG Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title-icon svg path' => 'fill: {{VALUE}}',
                ],

                'condition' => [
                    'title_icon!' => '',
                ]
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Excerpt Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item p' => 'color: {{VALUE}}',
                ],
            ]
        );
 
        $this->end_controls_tab();

        $this->start_controls_tab(
            'content_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Title Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'title_icon_line_color_hover',
            [
                'label' => __('Title Icon Line Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .title-icon svg path' => 'stroke: {{VALUE}}',
                ],
                'condition' => [
                    'title_icon!' => '',
                ]
                
            ]
        );

        $this->add_control(
            'title_icon_fill_color_hover',
            [
                'label' => __('SVG Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .title-icon svg path' => 'fill: {{VALUE}}',
                ],

                'condition' => [
                    'title_icon!' => '',
                ]
            ]
        );
        $this->add_control(
            'excerpt_hover_color',
            [
                'label' => __('Excerpt Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover p' => 'color: {{VALUE}}',
                ],
            ]
        );
     
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
            'title_br',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_responsive_control(
            'title_icon_size',
            [
                'label' => __('Icon size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-title svg' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .trydus-service-widget-item .service-title i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_icon_rotate',
            [
                'label' => __('Rotate icon', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -360,
                        'max' => 360,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-title svg, {{WRAPPER}} .trydus-service-widget-item .service-title i' => 'transform: rotate( {{SIZE}}deg );',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_gap',
            [
                'label' => __('Title Gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __('Title Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item .service-title' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Content Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item .service-content p' => 'padding: 
                    {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'content_box_padding',
            [
                'label' => __('Content Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item .service-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item .service-content' => 'padding: 
                    {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'button_style',
            [
                'label' => __('Button', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,   'condition' => [
                    'show_readmore' => 'yes',
                ]
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typography',
                'label' => __('Button Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .service-btn',
            ]
        );

        $this->start_controls_tabs(
            'button_style_tabs'
        );
        
        $this->start_controls_tab(
            'button_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-btn .btn-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-btn .btn-icon path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_fill_color',
            [
                'label' => __('Icon Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-btn .btn-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'boxed_btn_color',
            [
                'label' => __('Button Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'boxed_btn_background',
            [
                'label' => __('Background Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .service-btn',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'label' => __('Button Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .service-btn',
            ]
        );

        $this->add_responsive_control(
            'button_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-btn' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_gap',
            [
                'label' => __('Icon gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-btn .icon-before, body.rtl {{WRAPPER}} .service-btn .icon-after ' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-btn .icon-after , body.rtl  {{WRAPPER}} .service-btn .icon-before' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Icon Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-btn .btn-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-btn .btn-icon path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_fill_color_hover',
            [
                'label' => __('Icon Fill Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-btn .btn-icon path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_color',
            [
                'label' => __('Button Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover .service-btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_background',
            [
                'label' => __('Background Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_hover_border',
                'label' => __('Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .service-btn:hover',
            ]
        );

        $this->add_control(
            'btn_hover_animation',
            [
                'label' => __('Hover Animation', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_hover_shadow',
                'label' => __('Button Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .service-btn:hover',
            ]
        );

        $this->add_responsive_control(
            'button_hover_radius',
            [
                'label' => __('Border Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
       
        $this->add_control(
            'icon_hover_gap',
            [
                'label' => __('Icon gap', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .service-btn:hover .icon-before' => 'transform: translatex( -{{SIZE}}{{UNIT}} );',
                    '{{WRAPPER}} .service-btn:hover .icon-after ' => 'transform: translatex( {{SIZE}}{{UNIT}} );',
                   
                    'body.rtl {{WRAPPER}} .service-btn:hover .icon-before' => 'transform: translatex( {{SIZE}}{{UNIT}} );',
                    'body.rtl {{WRAPPER}} .service-btn:hover .icon-after ' => 'transform: translatex( -{{SIZE}}{{UNIT}} );',
                ],
            ]
        );


        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
            'buton_style_divider',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-btn .btn-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-btn .btn-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Button Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .service-btn' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_box_style',
            [
                'label' => __('Box', 'trydus-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'box_style_tabs'
        );
        
        $this->start_controls_tab(
            'box_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'box_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item',
            ]
        );

        $this->add_control(
            'hide_last_item_border',
            [
                'label' => __('Hide Last Item Border?', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'trydus-hp'),
                'label_off' => __('Hide', 'trydus-hp'),
                'return_value' => 'yes',
                'default' => 'no',
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-wrap:last-child .trydus-service-widget-item' => 'border-right: none',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-wrap:last-child .trydus-service-widget-item' => 'border-left: none',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'box_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'box_hover_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'defautl' => '#233aff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_hover_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_hover_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item:hover',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_hover_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-service-widget-item:hover ',
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-service-widget-item ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-service-widget-item ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();

        $the_query = new WP_Query(array(
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'service',
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        ));

        $post_grid_desktop = $settings['post_grid'];
        $post_grid_tablet  = $settings['post_grid_tablet'];
        $post_grid_mobile  = $settings['post_grid_mobile'];
        $post_grid = sprintf('col-lg-%s col-md-%s col-%s', esc_attr($post_grid_desktop), esc_attr($post_grid_tablet), esc_attr($post_grid_mobile)); 
        
        ?>
        <?php if ($the_query->have_posts()) : ?>
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

                        <?php
                            $idd = get_the_ID();
                            $excerpt = ($settings['excerpt_limit']['size']) ? wp_trim_words(get_the_excerpt(), $settings['excerpt_limit']['size'], '...') : get_the_excerpt();
                            $title = ($settings['title_limit']['size']) ? wp_trim_words(get_the_title(), $settings['title_limit']['size'], '...') : get_the_title();

                            ob_start();
                            Elementor\Icons_Manager::render_icon($settings['title_icon'], ['aria-hidden' => 'true']);
                            $title_icon = ob_get_clean();

                         ?>
                        
                        <div class="<?php echo $post_grid; ?> trydus-service-widget-wrap">
                            <div class="trydus-service-widget-item <?php printf('service-style-%s', esc_attr( $settings['service_style'] )) ?>">

                                <?php 
                                    if( 2 == $settings['service_style'] ):
                                        printf(
                                            ' <div class="service-top-title"> <a href="%s"> <h3 class="service-title">%s <span class="title-icon right">%s</span></h3> </a> </div>',
                                            esc_url( get_the_permalink() ),
                                            $title,
                                            $title_icon
                                        );
                                    endif;
                                ?> 
                                
                                <?php if (has_post_thumbnail() && 1 != $settings['service_style']) : ?>
                                    <div class="service-thumbnail-wrapper">
                                        <a href="<?php echo esc_url(  get_the_permalink(  )  )?>" class="service-thumbnail d-block">
                                          <?php the_post_thumbnail( 'full' ); ?>
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <?php if (!empty( get_post_meta( $idd, 'svg_icon', true ) ) ) : ?>
                                        <div class="service-thumbnail-wrapper">
                                            <div class="service-thumbnail">
                                                <?php if ('yes' == $settings['show_shape']): ?>
                                                <span class="image-shape"></span>
                                                <?php endif; ?>
                                                <?php
                                                    $thumb_icon_id = get_post_meta( $idd, 'svg_icon', true );
                                                    $thumb_icon_url = wp_get_attachment_image( $thumb_icon_id, 'full' );
                                                    $image =  [
                                                    'value' => [
                                                        'url' => $thumb_icon_url,
                                                        'id' => $thumb_icon_id,
                                                    ],
                                                    'library' => 'svg'
                                                ];
                                                    Elementor\Icons_Manager::render_icon($image, ['aria-hidden' => 'true']);
                                            ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <div class="service-content-wrap">
                                    <div class="service-content">
                                    <?php
                                        if( 2 != $settings['service_style'] ){
                                            printf('<a href="%s" class="service-title-link d-block"><h3 class="service-title">%s <span class="title-icon right">%s</span></h3></a>', get_the_permalink(  ), $title, $title_icon );
                                        }
                                         echo 'yes' == $settings['show_excerpt'] ? sprintf('<p> %s </p>', esc_html($excerpt)) : ''; 
     
                                    ?>
                                    </div>

                                    <?php if ('yes' == $settings['show_readmore']): ?>
                                    <div class="service-btn-wrap">
                                        <a class="service-btn <?php echo esc_attr('elementor-animation-' . $settings['btn_hover_animation']) ?>" href="<?php the_permalink() ?>">

                                            <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                                                <span class="icon-before btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                                            <?php endif; ?>

                                            <?php echo esc_html($settings['readmore_text']); ?>

                                            <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                                                <span class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                                            <?php endif; ?>

                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div> 
                    <?php
                        endwhile;
        wp_reset_postdata(); ?>
                </div>
            </div>
<?php
        endif;
    }
}




    

