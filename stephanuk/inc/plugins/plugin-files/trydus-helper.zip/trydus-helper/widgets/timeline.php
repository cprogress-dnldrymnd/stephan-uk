<?php
namespace Elementor;
/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Trydus_Timeline extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'trydus-timeline';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Trydus Timeline', 'trydus-hp');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-nav-menu';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['trydus-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls()
    {

        /**
         * Style tab
         */

        $this->start_controls_section(
            'general',
            [
                'label' => __('Content', 'trydus-hp'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
			'timeline_style',
			[
				'label' => __( 'Border Style', 'trydus-hp' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'vertical',
				'options' => [
					'vertical' => __( 'Vertucal', 'trydus-hp' ),
					'horizontal' => __( 'Horizontal', 'trydus-hp' ),
				],
			]
        );
    

		$repeater = new Repeater();

		$repeater->add_control(
			'time', [
				'label' => __( 'Time', 'trydus-hp' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'trydus-hp' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'info Title' , 'trydus-hp' ),
				'label_block' => true,
			]
        );

        $repeater->add_control(
			'timeline_position',
			[
				'label' => __( 'Position', 'trydus-hp' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
                    '' => __('Default', 'trydus-hp'),
					'1' => __( '1st Line', 'trydus-hp' ),
					'2' => __( '2nd Line', 'trydus-hp' ),
				],
			]
        );

        $repeater->add_responsive_control(
            'gap_control',
            [
                'label' => __('Timeline position', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} ' => 'left : {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} {{CURRENT_ITEM}}' => 'right: {{SIZE}}{{UNIT}};',
                ],

            ]
        );        

        $repeater->add_responsive_control(
            'width',
            [
                'label' => __('Timeline Width', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} ' => 'min-width : {{SIZE}}{{UNIT}};',
                ],

            ]
        );        
        
		$this->add_control(
			'timeline_items',
			[
				'label' => __( 'Timeline Items', 'trydus-hp' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'time' => __( '1982:', 'trydus-hp' ),
						'title' => __( 'Company launch', 'trydus-hp' ),
					],
				],
                'title_field' => '{{{ time }}}',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'section_tiem_style',
            [
                'label' => __('Time', 'trydus-hp'),
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        );
        $this->start_controls_tabs(
            'time_style_tabs'
        );
        
        $this->start_controls_tab(
            'time_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'time_typography',
                'label' => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-timeline__card-date',
            ]
        );

        $this->add_control(
            'time_color',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card-date' => 'color: {{VALUE}}',
    
                ],
            ]
        );

        $this->add_responsive_control(
            'time_gap',
            [
                'label' => __('Gap', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card-date' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],

            ]
        );       

        $this->end_controls_tab();

        $this->start_controls_tab(
            'time_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
                $this->add_control(
            'time_color_hover',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card_inner:hover .trydus-timeline__card-date' => 'color: {{VALUE}}',
    
                ],
            ]
        );
    $this->end_controls_tab();
        
        $this->end_controls_tabs();
               
        

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __('Title', 'trydus-hp'),
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        ); 

        $this->start_controls_tabs(
            'title_style_tabs'
        );
        
        $this->start_controls_tab(
            'title_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Typography', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-timeline__card-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card-title' => 'color: {{VALUE}}',
    
                ],
            ]
        ); 

        $this->end_controls_tab();

        $this->start_controls_tab(
            'title_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => __('Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .trydus-timeline__card_inner:hover .trydus-timeline__card-title' => 'color: {{VALUE}}',
    
                ],
            ]
        ); 
        
    $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->end_controls_section();
        
        $this->start_controls_section(
            'section_dot_line_style',
            [
                'label' => __('Dots & Line', 'trydus-hp'),
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __('Dots Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card:before' => 'background-color: {{VALUE}}',
    
                ],
            ]
        );  

        $this->add_responsive_control(
            'dot_size',
            [
                'label' => __('dot Size', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card:before' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],

            ]
        );  

        $this->add_responsive_control(
            'dot_radius',
            [
                'label' => __('Dot Radius', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card:before' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],

            ]
        );  

        $this->add_control(
			'line_style',
			[
				'label' => __( 'Line Style', 'trydus-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
        );
        
        $this->add_control(
            'line_color',
            [
                'label' => __('Line Color', 'trydus-hp'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline-wrapper:after' => 'background-color: {{VALUE}}',
    
                ],
            ]
        );  

        $this->add_responsive_control(
            'line_size',
            [
                'label' => __('Line Weight', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline-wrapper:after' => 'height: {{SIZE}}{{UNIT}};',
                ],

            ]
        );  

        $this->end_controls_section();

        $this->start_controls_section(
            'timeline_box_style',
            [
                'label' => __('Box style', 'trydus-hp'),
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        );
        
        $this->start_controls_tabs(
            'box_style_tabs'
        );
        
        $this->start_controls_tab(
            'box_style_normal_tab',
            [
                'label' => __('Normal', 'trydus-hp'),
            ]
        );

        $this->add_control(
            'box_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card_inner' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-timeline__card_inner',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => __('Box Border', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-timeline__card_inner',
            ]
        );

        $this->add_responsive_control(
            'wrapper_height',
            [
                'label' => __('Wrapper height', 'trydus-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline-area' => 'height: {{SIZE}}{{UNIT}};',
                ],

            ]
        );  


        $this->add_responsive_control(
            'box_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-timeline__card_inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-timeline__card_inner' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_padding',
            [
                'label' => __('Box Padding', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-timeline__card_inner ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-timeline__card_inner ' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'box_style_hover_tab',
            [
                'label' => __('Hover', 'trydus-hp'),
            ]
        );
        
        $this->add_control(
            'box_hover_bg_color',
            [
                'label' => __('Box Backgroound Color', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'defautl' => '#233aff',
                'selectors' => [
                    '{{WRAPPER}} .trydus-timeline__card_inner:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'box_hover_shadow',
                'label' => __('Box Hover Shadow', 'trydus-hp'),
                'selector' => '{{WRAPPER}} .trydus-timeline__card_inner:hover',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_hover_border',
                'label' => __('Box Border', ''),
                'selector' => '{{WRAPPER}} .trydus-timeline__card_inner:hover ',
            ]
        );
        
        $this->add_responsive_control(
            'box_hover_radius',
            [
                'label' => __('Box Radius', 'trydus-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .trydus-timeline__card_inner:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .trydus-timeline__card_inner:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $popular_post_key = array();
        $popular_meta_value_num = array();
        $settings = $this->get_settings_for_display();
       
?>
<div class="trydus-timeline-area">
    <div class="trydus-timeline-wrapper">
        <?php foreach ( $settings['timeline_items'] as $timeline ): ?>
        <div class="trydus-timeline__card <?php printf( 'elementor-repeater-item-%s timeline-position-%s',esc_attr( $timeline['_id'] ), esc_attr( $timeline['timeline_position'] ) ); ?>">
            <div class="trydus-timeline__card_inner">
                <div class="trydus-timeline__card-date">
                <?php echo esc_html( $timeline['time'] ); ?>
            </div>
            <div class="trydus-timeline__card-title">
                <?php echo esc_html( $timeline['title'] ); ?>
            </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
    }
}
